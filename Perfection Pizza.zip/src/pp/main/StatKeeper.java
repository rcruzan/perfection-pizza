package pp.main;

public class StatKeeper {
	
	public static int d1, d2, d3, d4, d5, d6, d7, d8, d9, d10,
					  d11,d12,d13,d14,d15,d16,d17,d18,d19,d20,
					  d21,d22,d23,d24,d25,d26,d27,d28,d29,d30;
	
	public StatKeeper() {
		
	}

	public static void profitSet(int money, int day) {
		if(day - 1 == 1) {
			d1 = (int) (money / 7.8);
		}
		else if(day - 1 == 2) {
			d2 = (int) (money / 7.8);
		}
		else if(day - 1 == 3) {
			d3 = (int) (money / 7.8);
		}
		else if(day - 1 == 4) {
			d4 = (int) (money / 7.8);
		}
		else if(day - 1 == 5) {
			d5 = (int) (money / 7.8);
		}
		else if(day - 1 == 6) {
			d6 = (int) (money / 7.8);
		}
		else if(day - 1 == 7) {
			d7 = (int) (money / 7.8);
		}
		else if(day - 1 == 8) {
			d8 = (int) (money / 7.8);	
		}
		else if(day - 1 == 9) {
			d9 = (int) (money / 7.8);
		}
		else if(day - 1 == 10) {
			d10 = (int) (money / 7.8);
		}
		else if(day - 1 == 11) {
			d11 = (int) (money / 7.8);
		}
		else if(day - 1 == 12) {
			d12 = (int) (money / 7.8);
		}
		else if(day - 1 == 13) {
			d13 = (int) (money / 7.8);
		}
		else if(day - 1 == 14) {
			d14 = (int) (money / 7.8);
		}
		else if(day - 1 == 15) {
			d15 = (int) (money / 7.8);
		}
		else if(day - 1 == 16) {
			d16 = (int) (money / 7.8);
		}
		else if(day - 1 == 17) {
			d17 = (int) (money / 7.8);
		}
		else if(day - 1 == 18) {
			d18 = (int) (money / 7.8);
		}
		else if(day - 1 == 19) {
			d19 = (int) (money / 7.8);
		}
		else if(day - 1 == 20) {
			d20 = (int) (money / 7.8);
		}
		else if(day - 1 == 21) {
			d21 = (int) (money / 7.8);
		}
		else if(day - 1 == 22) {
			d22 = (int) (money / 7.8);
		}
		else if(day - 1 == 23) {
			d23 = (int) (money / 7.8);
		}
		else if(day - 1 == 24) {
			d24 = (int) (money / 7.8);
		}
		else if(day - 1 == 25) {
			d25 = (int) (money / 7.8);
		}
		else if(day - 1 == 26) {
			d26 = (int) (money / 7.8);
		}
		else if(day - 1 == 27) {
			d27 = (int) (money / 7.8);
		}
		else if(day - 1 == 28) {
			d28 = (int) (money / 7.8);
		}
		else if(day - 1 == 29) {
			d29 = (int) (money / 7.8);
		}
		else if(day - 1 == 30) {
			d30 = (int) (money / 7.8);
		}
	}
}
