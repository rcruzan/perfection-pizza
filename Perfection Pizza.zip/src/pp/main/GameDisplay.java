package pp.main;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import pp.AudioPlayer;
import pp.Game;
import pp.characters.ID;
import pp.particles.MenuParticle;

public class GameDisplay {

	private Handler handler;
	@SuppressWarnings("unused")
	private Menu menu;
	@SuppressWarnings("unused")
	private Game game;
	@SuppressWarnings("unused")
	private HUD hud;
	
	public enum STATE {
		DayCounter,
		Gameplay,
		DayOver
	};
	
	public static int dough = 0, sauce = 0, mozz = 0, ched = 0, pepp = 0, saus = 0, 
			          mush = 0, onion = 0, olives = 0, spin = 0, isCooked = 0, isCut = 0;
	public static STATE displayState = STATE.DayCounter;
	public static boolean isCooking = false;
	public static int timer = 0;
	
	public GameDisplay(Game game, Handler handler, HUD hud) {
		this.handler = handler;
		this.game = game;
		this.hud = hud;
	}
	
	public void tick() {
		timer++;
		
		if(isCooking == true) {
			if(timer >= (300 - UpgradeKeeper.cooktimeMinus)) {
				isCooking = false;
				isCooked = 1;
				if(!Game.muted) {
					AudioPlayer.getSound("ovenHum").stop();
					AudioPlayer.getSound("ovenDing").play(1, 0.1f);
				}
			}
		}
	}
	
		public void render(Graphics g) {
			
		Toolkit k = Toolkit.getDefaultToolkit();
		
		Image room = k.getImage(getClass().getClassLoader().getResource("images/store/StoreDisplay.png"));
		Image ovenCook = k.getImage(getClass().getClassLoader().getResource("images/store/ovenCooking.png"));
		Image empty = k.getImage(getClass().getClassLoader().getResource("images/store/emptyContainer.png"));
		Image emptyLong = k.getImage(getClass().getClassLoader().getResource("images/store/emptyContainer2.png"));
		
		Image wallpaper = k.getImage(getClass().getClassLoader().getResource("images/upgrades/wallpaperNew.png"));
		Image poster1 = k.getImage(getClass().getClassLoader().getResource("images/upgrades/poster1.png"));
		Image poster2 = k.getImage(getClass().getClassLoader().getResource("images/upgrades/poster2.png"));
		Image lamp = k.getImage(getClass().getClassLoader().getResource("images/upgrades/lamp.png"));
		Image plant = k.getImage(getClass().getClassLoader().getResource("images/upgrades/plant.png"));
		
		g.drawImage(room, 53, -5, null); 
		g.drawImage(ovenCook, 450, 613, null); 
		
		if(UpgradeKeeper.wallpaperBought == 1) {
			g.drawImage(wallpaper, 59, -5, null);
		}
		if(UpgradeKeeper.poster1Bought == 1) {
			g.drawImage(poster1, 175, 114, null);
		}
		if(UpgradeKeeper.poster2Bought == 1) {
			g.drawImage(poster2, 555, 114, null);
		}
		if(UpgradeKeeper.plantsBought == 1) {
			g.drawImage(plant, 37, 82, null);
			g.drawImage(plant, 722, 82, null);
		}
		if(UpgradeKeeper.lampsBought == 1) {
			g.drawImage(lamp, 35, 30, null);
			g.drawImage(lamp, 720, 30, null);
		}
		
		if(UpgradeKeeper.uMush == 0) {
			g.drawImage(empty, 164, 447, null);
		}
		if(UpgradeKeeper.uOlive == 0) {
			g.drawImage(empty, 254, 447, null);
		}
		if(UpgradeKeeper.uSaus == 0) {
			g.drawImage(empty, 74, 507, null);
		}
		if(UpgradeKeeper.uOnion == 0) {
			g.drawImage(empty, 164, 507, null);
		}
		if(UpgradeKeeper.uSpin == 0) {
			g.drawImage(empty, 254, 507, null);
		}
		if(UpgradeKeeper.uChed == 0) {
			g.drawImage(emptyLong, 636, 508, null);
		}
			
		// DAY COUNTER
		if(displayState == STATE.DayCounter) {
			Font f = new Font("Haettenschweiler", Font.PLAIN, 90);
			g.setColor(Color.BLACK);
			g.fillRect(0, 0, Game.WIDTH, Game.HEIGHT);
			
			if(timer >= 100 && timer <= 250) {
				if(HUD.getDay() <= 9) {
					g.setFont(f);
					g.setColor(Color.WHITE);
					g.drawString("DAY " + HUD.getDay(), 360, 300);
				}
				else {
					g.setFont(f);
					g.setColor(Color.WHITE);
					g.drawString("DAY " + HUD.getDay(), 340, 300);
				}
			}
			if(timer >= 350) {
				if(!Game.muted) {
				AudioPlayer.getMusic("epicMusic").loop(1, 0.1f);
				}
				displayState = STATE.Gameplay;
			}
		}
		
		// GAMEPLAY
		if(displayState == STATE.Gameplay) {
			g.setColor(Color.ORANGE.darker());	// SIDE BARS
			g.fillRect(0, 0, 66, 700);
			g.fillRect(828, 0, 66, 700);
			
		//	g.setColor(Color.RED);
		//	g.fillRect(355, 175, 160, 202);
			
			g.setColor(Color.BLACK);
			g.drawLine(66, 0, 66, 1000);
			g.drawLine(828, 0, 828, 1000);
			
			if(!isCooking) {
			g.setColor(Color.BLACK);
			g.fillRect(478, 635, 301, 50);
			
			// *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
			
			if(dough == 1 && isCooked == 0 && isCooking == false) {
				g.setColor(Color.ORANGE);
				g.fillRoundRect(375, 405, 130, 130, 130, 130);
				g.setColor(Color.BLACK);
				g.drawRoundRect(375, 405, 130, 130, 130, 130);
			}
			
			if(dough == 1 && isCooked == 1 && isCooking == false) {
				g.setColor(Color.ORANGE.darker());
				g.fillRoundRect(375, 405, 130, 130, 130, 130);
				g.setColor(Color.BLACK);
				g.drawRoundRect(375, 405, 130, 130, 130, 130);
			}
			
			if(sauce == 1 && isCooked == 0 && isCooking == false) {
				g.setColor(Color.RED);
				g.fillRoundRect(381, 411, 118, 118, 118, 118);
				g.setColor(Color.BLACK);
				g.drawRoundRect(381, 411, 118, 118, 118, 118);
			}
			
			if(sauce == 1 && isCooked == 1 && isCooking == false) {
				g.setColor(Color.RED.darker());
				g.fillRoundRect(381, 411, 118, 118, 118, 118);
				g.setColor(Color.BLACK);
				g.drawRoundRect(381, 411, 118, 118, 118, 118);
			}
			
			if(mozz == 1 && isCooked == 0 && isCooking == false) {
				g.setColor(Color.YELLOW);
				g.fillRoundRect(387, 417, 106, 106, 106, 106);
				g.setColor(Color.BLACK);
				g.drawRoundRect(387, 417, 106, 106, 106, 106);
			}
			
			if(mozz == 1 && isCooked == 1 && isCooking == false) {
				g.setColor(Color.ORANGE);
				g.fillRoundRect(387, 417, 106, 106, 106, 106);
				g.setColor(Color.YELLOW);
				g.fillRoundRect(391, 421, 98, 98, 98, 98);
				g.setColor(Color.BLACK);
				g.drawRoundRect(387, 417, 106, 106, 106, 106);
			}
			
			if(ched == 1 && isCooked == 0 && isCooking == false) {
				g.setColor(Color.ORANGE);
				g.fillRoundRect(387, 417, 106, 106, 106, 106);
				g.setColor(Color.BLACK);
				g.drawRoundRect(387, 417, 106, 106, 106, 106);
			}
			
			if(ched == 1 && isCooked == 1 && isCooking == false) {
				g.setColor(Color.ORANGE.darker());
				g.fillRoundRect(387, 417, 106, 106, 106, 106);
				g.setColor(Color.ORANGE);
				g.fillRoundRect(391, 421, 98, 98, 98, 98);
				g.setColor(Color.BLACK);
				g.drawRoundRect(387, 417, 106, 106, 106, 106);
			}
			
			if(pepp == 1 && isCooked == 0 && isCooking == false) {
				g.setColor(Color.RED);
				g.fillRoundRect(400, 450, 15, 15, 15, 15);
				g.fillRoundRect(430, 470, 15, 15, 15, 15);
				g.fillRoundRect(455, 460, 15, 15, 15, 15);
				g.fillRoundRect(438, 430, 15, 15, 15, 15);
				g.fillRoundRect(410, 490, 15, 15, 15, 15);
				g.fillRoundRect(457, 487, 15, 15, 15, 15);
				g.setColor(Color.BLACK);
				g.drawRoundRect(400, 450, 15, 15, 15, 15);
				g.drawRoundRect(430, 470, 15, 15, 15, 15);
				g.drawRoundRect(455, 460, 15, 15, 15, 15);
				g.drawRoundRect(438, 430, 15, 15, 15, 15);
				g.drawRoundRect(410, 490, 15, 15, 15, 15);
				g.drawRoundRect(457, 487, 15, 15, 15, 15);
			}
			
			if(pepp == 1 && isCooked == 1 && isCooking == false) {
				g.setColor(Color.RED.darker());
				g.fillRoundRect(400, 450, 15, 15, 15, 15);
				g.fillRoundRect(430, 470, 15, 15, 15, 15);
				g.fillRoundRect(455, 460, 15, 15, 15, 15);
				g.fillRoundRect(438, 430, 15, 15, 15, 15);
				g.fillRoundRect(410, 490, 15, 15, 15, 15);
				g.fillRoundRect(457, 487, 15, 15, 15, 15);
				g.setColor(Color.BLACK);
				g.drawRoundRect(400, 450, 15, 15, 15, 15);
				g.drawRoundRect(430, 470, 15, 15, 15, 15);
				g.drawRoundRect(455, 460, 15, 15, 15, 15);
				g.drawRoundRect(438, 430, 15, 15, 15, 15);
				g.drawRoundRect(410, 490, 15, 15, 15, 15);
				g.drawRoundRect(457, 487, 15, 15, 15, 15);
			}
			
			if(saus == 1 && isCooking == false) {
				g.setColor(Color.ORANGE.darker().darker().darker());
				g.fillRoundRect(450, 450, 8, 8, 8, 8);
				g.fillRoundRect(424, 430, 8, 8, 8, 8);
				g.fillRoundRect(439, 497, 8, 8, 8, 8);
				g.fillRoundRect(415, 474, 8, 8, 8, 8);
				g.fillRoundRect(393, 463, 8, 8, 8, 8);
				g.fillRoundRect(475, 470, 8, 8, 8, 8);
				g.setColor(Color.BLACK);
				g.drawRoundRect(450, 450, 8, 8, 8, 8);
				g.drawRoundRect(424, 430, 8, 8, 8, 8);
				g.drawRoundRect(439, 497, 8, 8, 8, 8);
				g.drawRoundRect(415, 474, 8, 8, 8, 8);
				g.drawRoundRect(393, 463, 8, 8, 8, 8);
				g.drawRoundRect(475, 470, 8, 8, 8, 8);
			}
			
			if(mush == 1 && isCooking == false) {
				g.setColor(Color.WHITE);
				g.fillRoundRect(463, 440, 10, 8, 10, 8);
				g.fillRoundRect(423, 450, 10, 8, 10, 8);
				g.fillRoundRect(447, 480, 10, 8, 10, 8);
				g.fillRoundRect(397, 480, 10, 8, 10, 8);
				g.fillRoundRect(427, 505, 10, 8, 10, 8);
				g.setColor(Color.BLACK);
				g.drawRoundRect(463, 440, 10, 8, 10, 8);
				g.drawRoundRect(423, 450, 10, 8, 10, 8);
				g.drawRoundRect(447, 480, 10, 8, 10, 8);
				g.drawRoundRect(397, 480, 10, 8, 10, 8);
				g.drawRoundRect(427, 505, 10, 8, 10, 8);
			}
			
			if(olives == 1 && isCooking == false) {
				g.setColor(Color.BLACK);
				g.drawRoundRect(445, 455, 4, 4, 4, 4);
				g.drawRoundRect(410, 470, 4, 4, 4, 4);
				g.drawRoundRect(440, 490, 4, 4, 4, 4);
				g.drawRoundRect(430, 425, 4, 4, 4, 4);
				g.drawRoundRect(473, 485, 4, 4, 4, 4);
				g.drawRoundRect(483, 455, 4, 4, 4, 4);
				g.drawRoundRect(405, 440, 4, 4, 4, 4);
			}
			
			if(onion == 1 && isCooked == 0 && isCooking == false) {
				g.setColor(Color.WHITE);
				g.drawRoundRect(421, 461, 9, 9, 9, 9);
				g.drawRoundRect(441, 511, 9, 9, 9, 9);
				g.drawRoundRect(471, 451, 9, 9, 9, 9);
				g.drawRoundRect(411, 431, 9, 9, 9, 9);
				g.drawRoundRect(399, 492, 9, 9, 9, 9);
				g.setColor(Color.MAGENTA);
				g.drawRoundRect(420, 460, 9, 9, 9, 9);
				g.drawRoundRect(440, 510, 9, 9, 9, 9);
				g.drawRoundRect(470, 450, 9, 9, 9, 9);
				g.drawRoundRect(410, 430, 9, 9, 9, 9);
				g.drawRoundRect(398, 491, 9, 9, 9, 9);
			}
			
			if(onion == 1 && isCooked == 1 && isCooking == false) {
				g.setColor(Color.WHITE.darker());
				g.drawRoundRect(421, 461, 9, 9, 9, 9);
				g.drawRoundRect(441, 511, 9, 9, 9, 9);
				g.drawRoundRect(471, 451, 9, 9, 9, 9);
				g.drawRoundRect(411, 431, 9, 9, 9, 9);
				g.drawRoundRect(399, 492, 9, 9, 9, 9);
				g.setColor(Color.MAGENTA.darker());
				g.drawRoundRect(420, 460, 9, 9, 9, 9);
				g.drawRoundRect(440, 510, 9, 9, 9, 9);
				g.drawRoundRect(470, 450, 9, 9, 9, 9);
				g.drawRoundRect(410, 430, 9, 9, 9, 9);
				g.drawRoundRect(398, 491, 9, 9, 9, 9);
			}
			
			if(spin == 1 && isCooked == 0 && isCooking == false) {
				g.setColor(Color.GREEN.darker());
				g.fillRoundRect(455, 428, 16, 10, 16, 10);
				g.fillRoundRect(452, 503, 16, 10, 16, 10);
				g.fillRoundRect(420, 487, 16, 10, 16, 10);
				g.fillRoundRect(412, 440, 16, 10, 16, 10);
				g.fillRoundRect(387, 472, 16, 10, 16, 10);
				g.fillRoundRect(475, 488, 16, 10, 16, 10);
				g.setColor(Color.BLACK);
				g.drawRoundRect(455, 428, 16, 10, 16, 10);
				g.drawRoundRect(452, 503, 16, 10, 16, 10);
				g.drawRoundRect(420, 487, 16, 10, 16, 10);
				g.drawRoundRect(412, 440, 16, 10, 16, 10);
				g.drawRoundRect(387, 472, 16, 10, 16, 10);
				g.drawRoundRect(475, 488, 16, 10, 16, 10);
			}
			
			if(spin == 1 && isCooked == 1 && isCooking == false) {
				g.setColor(Color.GREEN.darker().darker());
				g.fillRoundRect(455, 428, 16, 10, 16, 10);
				g.fillRoundRect(452, 503, 16, 10, 16, 10);
				g.fillRoundRect(420, 487, 16, 10, 16, 10);
				g.fillRoundRect(412, 440, 16, 10, 16, 10);
				g.fillRoundRect(387, 472, 16, 10, 16, 10);
				g.fillRoundRect(475, 488, 16, 10, 16, 10);
				g.setColor(Color.BLACK);
				g.drawRoundRect(455, 428, 16, 10, 16, 10);
				g.drawRoundRect(452, 503, 16, 10, 16, 10);
				g.drawRoundRect(420, 487, 16, 10, 16, 10);
				g.drawRoundRect(412, 440, 16, 10, 16, 10);
				g.drawRoundRect(387, 472, 16, 10, 16, 10);
				g.drawRoundRect(475, 488, 16, 10, 16, 10);
			}
			
			// *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
			
			if(isCut == 1) {
				g.setColor(Color.BLACK);
				g.drawLine(440, 405, 440, 535);
				g.drawLine(375, 470, 505, 470);
				g.drawLine(390, 510, 490, 430);
				g.drawLine(395, 425, 487, 516);
			}
		}
	}
		
		// DAY OVER
		if(displayState == STATE.DayOver) {
			Font f = new Font("Haettenschweiler", Font.PLAIN, 90);
			g.setColor(Color.BLACK);
			g.fillRect(0, 0, Game.WIDTH, Game.HEIGHT);
			
			if(timer >= 100 && timer <= 250) {
				g.setFont(f);
				g.setColor(Color.WHITE);
				g.drawString("TIME'S UP!", 290, 300);
			}
			if(timer >= 350 && HUD.getDay() != 31) {
				if(!Game.muted) {
			  		AudioPlayer.getMusic("epicMusic").stop();
			  		AudioPlayer.getMusic("endMusic").loop(1, 0.1f);
			  	}
				new MenuParticle(0, 0, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(33, 33, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(0, 66, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(33, 99, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(0, 132, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(33, 165, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(0, 198, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(33, 231, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(0, 264, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(33, 297, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(0, 330, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(33, 363, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(0, 396, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(33, 429, ID.MenuParticle, handler, Color.BLACK);
				
				new MenuParticle(861, 0, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(828, 33, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(861, 66, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(828, 99, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(861, 132, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(828, 165, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(861, 198, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(828, 231, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(861, 264, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(828, 297, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(861, 330, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(828, 363, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(861, 396, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(828, 429, ID.MenuParticle, handler, Color.BLACK);	
				
				handler.clearCustomers();
				Game.gameState = Game.STATE.Menu;
			}
			else if(timer >= 350 && HUD.getDay() >= 31) {
				if(!Game.muted) {
			  		AudioPlayer.getMusic("epicMusic").stop();
			  		AudioPlayer.getMusic("endMusic").loop(1, 0.1f);
			  	}
			
				new MenuParticle(0, 0, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(33, 33, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(0, 66, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(33, 99, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(0, 132, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(33, 165, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(0, 198, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(33, 231, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(0, 264, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(33, 297, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(0, 330, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(33, 363, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(0, 396, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(33, 429, ID.MenuParticle, handler, Color.BLACK);
				
				new MenuParticle(861, 0, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(828, 33, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(861, 66, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(828, 99, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(861, 132, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(828, 165, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(861, 198, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(828, 231, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(861, 264, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(828, 297, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(861, 330, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(828, 363, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(861, 396, ID.MenuParticle, handler, Color.BLACK);
				new MenuParticle(828, 429, ID.MenuParticle, handler, Color.BLACK);	
				
				handler.clearCustomers();
				Game.gameState = Game.STATE.End;
			}
		}
	}
}
