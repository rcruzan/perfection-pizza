package pp.main;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import pp.AudioPlayer;
import pp.Game;
import pp.characters.Anna;
import pp.characters.Bill;
import pp.characters.Brucie;
import pp.characters.Charlie;
import pp.characters.Clint;
import pp.characters.Dave;
import pp.characters.Jackson;
import pp.characters.Maxwell;
import pp.characters.Paula;
import pp.characters.Sheryl;
import pp.characters.Spawn;

public class Menu extends MouseAdapter {

	private Handler handler;
	private Game game;
	@SuppressWarnings("unused")
	private HUD hud;
	
	static int score = 0;
	static int timer = 0;
	public static boolean tooPoor = false;
	public static boolean scoreShowing = false;
	public static boolean hover1 = false, hover2 = false, hover3 = false;
	
	public Menu(Game game, Handler handler, HUD hud) {
		this.hud = hud;
		this.game = game;
		this.handler = handler;
	}
	
	@SuppressWarnings("static-access")
	public void mousePressed(MouseEvent e) {
		int mx = e.getX();
		int my = e.getY();
		
		if(game.gameState == Game.STATE.Main) {	
		
		// PLAY
		if(mouseOver(mx, my, (int) (Game.WIDTH / 3) + 13, 308, 240, 64)) {
			if(!Game.muted) {
				AudioPlayer.getSound("click").play(1, 0.15f);
				AudioPlayer.getMusic("mainMusic").stop();
			}
			handler.clearParticles();
			game.gameState = Game.STATE.Game;
		}
		// HELP
		if(mouseOver(mx, my, (int) (Game.WIDTH / 3) + 13, 408, 240, 64)) {
			if(!Game.muted) {
				AudioPlayer.getSound("click").play(1, 0.15f);
			}
			game.gameState = Game.STATE.Help;
		}
		// QUIT
		if(mouseOver(mx, my, (int) (Game.WIDTH / 3) + 13, 508, 240, 64)) {
			System.exit(1);	
		}
		// CREDITS
		if(mouseOver(mx, my, 375, 159, 120, 120)) {
			if(!Game.muted) {
				AudioPlayer.getSound("click").play(1, 0.15f);
			}
			game.gameState = Game.STATE.Credits;
			}
		}
		
		// BACK BUTTON for HELP SCREEN
		if(game.gameState == Game.STATE.Help) {
			
			if(mouseOver(mx, my, (int) (Game.WIDTH / 3) + 13, 508, 240, 64)) {
			if(!Game.muted) {
			AudioPlayer.getSound("click").play(1, 0.15f);
			}
			game.gameState = Game.STATE.Main;
			return;
			}
		}
		
		// BACK BUTTON for CREDITS SCREEN
		if(game.gameState == Game.STATE.Credits) {
					
			if(mouseOver(mx, my, (int) (Game.WIDTH / 3) + 13, 508, 240, 64)) {
			if(!Game.muted) {
			AudioPlayer.getSound("click").play(1, 0.15f);
			}
			game.gameState = Game.STATE.Main;
			return;
			}
		}
		
		if(game.gameState == Game.STATE.End) {
			if(mouseOver(mx, my, (int) (Game.WIDTH / 3) + 14, 509, 240, 64)) {
				System.exit(1);
			}
		}
		
		if(game.gameState == Game.STATE.Game) {
			
			// PAUSE BUTTON
			if(mouseOver(mx, my, 831, 5, 58, 58)) {
				if(!Game.muted) {
					AudioPlayer.getSound("click").play(1, 0.15f);
				}
				if(!Game.paused) {
					Game.paused = true;
					return;
				}
				else {
					Game.paused = false;
					return;
				}
			}
			
			// TRASH BUTTON
			if(mouseOver(mx, my, 831, 581, 58, 58)) {
				if(Game.paused == false && GameDisplay.isCooking == false && GameDisplay.dough != 0) {
					GameDisplay.dough = 0;
					GameDisplay.sauce = 0;
					GameDisplay.mozz = 0;
					GameDisplay.ched = 0;
					GameDisplay.pepp = 0;
					GameDisplay.saus = 0;
					GameDisplay.mush = 0;
					GameDisplay.onion = 0;
					GameDisplay.olives = 0;
					GameDisplay.spin = 0;
					GameDisplay.isCooked = 0;
					GameDisplay.isCut = 0;
					if(!Game.muted) {
						AudioPlayer.getSound("trash").play(1, 0.11f);
					}
				}
			}
			
			/* PIZZA INGREDIENTS:
			   0 for false, 1 for true
			   
			   1.  dough
			   2.  tomato sauce
			   3.  mozzarella cheese
			   4.  cheddar cheese
			   5.  pepperoni
			   6.  sausage
			   7.  mushrooms
			   8.  onions
			   9.  black olives
			   10. spinach
			   11. is cooked
			*/
			
			// DOUGH
			if(mouseOver(mx, my, 733, 449, 87, 48)) {
				if(GameDisplay.dough == 0 && Game.paused == false) {
					GameDisplay.dough = 1;
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
				}
			}
			
			// SAUCE
			if(mouseOver(mx, my, 539, 449, 87, 108)) {
				if(GameDisplay.sauce == 0 && GameDisplay.dough == 1 && Game.paused == false && GameDisplay.isCooked == 0) {
					GameDisplay.sauce = 1;
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
				}
			}
			
			// MOZZ. CHEESE
			if(mouseOver(mx, my, 636, 449, 87, 48)) {
				if(GameDisplay.mozz != 1 && GameDisplay.ched == 0 && GameDisplay.dough == 1 && GameDisplay.sauce == 1 && Game.paused == false && GameDisplay.isCooked == 0) {
					GameDisplay.mozz = 1;
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
				}
			}
			
			// CHED. CHEESE
			if(mouseOver(mx, my, 636, 508, 87, 48)) {
				if(GameDisplay.ched != 1 && GameDisplay.mozz == 0 && GameDisplay.dough == 1 && GameDisplay.sauce == 1 && Game.paused == false && GameDisplay.isCooked == 0) {
					GameDisplay.ched = 1;
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
				}
			}
			
			// PEPPERONI
			if(mouseOver(mx, my, 74, 447, 79, 51)) {
				if(GameDisplay.pepp != 1 && GameDisplay.dough == 1 && (GameDisplay.mozz == 1 || GameDisplay.ched == 1) && Game.paused == false && GameDisplay.isCooked == 0) {
					GameDisplay.pepp = 1;
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
				}
			}
			
			// SAUSAGE
			if(mouseOver(mx, my, 74, 507, 79, 51)) {
				if(UpgradeKeeper.uSaus != 0 && GameDisplay.saus != 1 && GameDisplay.dough == 1 && (GameDisplay.mozz == 1 || GameDisplay.ched == 1) && Game.paused == false && GameDisplay.isCooked == 0) {
					GameDisplay.saus = 1;
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
				}
			}
			
			// MUSHROOM
			if(mouseOver(mx, my, 164, 447, 79, 51)) {
				if(UpgradeKeeper.uMush != 0 && GameDisplay.mush != 1 && GameDisplay.dough == 1 && (GameDisplay.mozz == 1 || GameDisplay.ched == 1) && Game.paused == false && GameDisplay.isCooked == 0) {
					GameDisplay.mush = 1;
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
				}
			}
			
			// BLACK OLIVES
			if(mouseOver(mx, my, 254, 447, 79, 51)) {
				if(UpgradeKeeper.uOlive != 0 && GameDisplay.olives != 1 && GameDisplay.dough == 1 && (GameDisplay.mozz == 1 || GameDisplay.ched == 1) && Game.paused == false && GameDisplay.isCooked == 0) {
					GameDisplay.olives = 1;
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
				}
			}
			
			// ONIONS
			if(mouseOver(mx, my, 164, 507, 79, 51)) {
				if(UpgradeKeeper.uOnion != 0 && GameDisplay.onion != 1 && GameDisplay.dough == 1 && (GameDisplay.mozz == 1 || GameDisplay.ched == 1) && Game.paused == false && GameDisplay.isCooked == 0) {
					GameDisplay.onion = 1;
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
				}
			}
			
			// SPINACH
			if(mouseOver(mx, my, 254, 507, 79, 51)) {
				if(UpgradeKeeper.uSpin != 0 && GameDisplay.spin != 1 && GameDisplay.dough == 1 && (GameDisplay.mozz == 1 || GameDisplay.ched == 1) && Game.paused == false && GameDisplay.isCooked == 0) {
					GameDisplay.spin = 1;
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
				}
			}
			
			// PIZZA CUTTER
			if(mouseOver(mx, my, 253, 395, 75, 45)) {
				if(GameDisplay.dough != 0 && GameDisplay.isCooked == 1 && GameDisplay.isCut != 1 && Game.paused == false) {
					GameDisplay.isCut = 1;
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
				}
			}
			
			// PIZZA OVEN
			if(mouseOver(mx, my, 450, 613, 352, 48)) {
				if(GameDisplay.dough != 0 && GameDisplay.isCooked == 0 && GameDisplay.isCooking == false && Game.paused == false) {
					GameDisplay.isCooking = true;
					GameDisplay.timer = 0;
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
						AudioPlayer.getSound("ovenHum").loop(1, 0.2f);
					}
				}
			}
			
			// CUSTOMER
			if(mouseOver(mx, my, 355, 175, 160, 202) && Game.paused == false && GameDisplay.isCooking == false) {
				int extraMoney = 0;
				if(GameDisplay.dough != 0 && scoreShowing == false) {
					scoreShowing = true;
					
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					
					if(Spawn.daveSpawn == 1) {
						score = Dave.scoreCheck();
					}
					else if(Spawn.billSpawn == 1) {
						score = Bill.scoreCheck();
					}
					else if(Spawn.clintSpawn == 1) {
						score = Clint.scoreCheck();
					}
					else if(Spawn.annaSpawn == 1) {
						score = Anna.scoreCheck();
					}
					else if(Spawn.paulaSpawn == 1) {
						score = Paula.scoreCheck();
					}
					else if(Spawn.jacksonSpawn == 1) {
						score = Jackson.scoreCheck();
					}
					else if(Spawn.sherylSpawn == 1) {
						score = Sheryl.scoreCheck();
					}
					else if(Spawn.charlieSpawn == 1) {
						score = Charlie.scoreCheck();
					}
					else if(Spawn.maxwellSpawn == 1) {
						score = Maxwell.scoreCheck();
					}
					else if(Spawn.brucieSpawn == 1) {
						score = Brucie.scoreCheck();
					}
					
					extraMoney = extraMoney + UpgradeKeeper.saucePlus;
					if(GameDisplay.mozz == 1) {
						extraMoney = extraMoney + UpgradeKeeper.mozzPlus;	
					}
					if(GameDisplay.ched == 1) {
						extraMoney = extraMoney + UpgradeKeeper.chedPlus;
					}
					if(GameDisplay.pepp == 1) {
						extraMoney = extraMoney + UpgradeKeeper.peppPlus;
					}
					if(GameDisplay.saus == 1) {
						extraMoney = extraMoney + UpgradeKeeper.sausPlus;
					}
					if(GameDisplay.mush == 1) {
						extraMoney = extraMoney + UpgradeKeeper.mushPlus;
					}
					if(GameDisplay.onion == 1) {
						extraMoney = extraMoney + UpgradeKeeper.onionPlus;
					}
					if(GameDisplay.olives == 1) {
						extraMoney = extraMoney + UpgradeKeeper.olivePlus;
					}
					if(GameDisplay.spin == 1) {
						extraMoney = extraMoney + UpgradeKeeper.spinPlus;
					}
					
					if(score == 100) {
						HUD.money = HUD.money + ((12 + extraMoney) * UpgradeKeeper.moneyMultiplier);
					}
					else if(score >= 75 && score < 100) {
						HUD.money = HUD.money + ((9 + extraMoney) * UpgradeKeeper.moneyMultiplier);
					}
					else if(score >= 50 && score < 75) {
						HUD.money = HUD.money + ((7 + extraMoney) * UpgradeKeeper.moneyMultiplier);
					}
					else if(score < 50 && score > 0) {
						HUD.money = HUD.money + ((3 + extraMoney) * UpgradeKeeper.moneyMultiplier);
					}
					
					timer = 0;
					extraMoney = 0;
			}
		}
	}
		
		if(game.gameState == Game.STATE.Menu) {
			// NEXT DAY BUTTON
			if(mouseOver(mx, my, 405, 530, 50, 50)) {
				if(!Game.muted) {
					AudioPlayer.getSound("click").play(1, 0.15f);
				}
				Game.gameState = Game.STATE.Confirm;
				return;
			}
			// LEFT BUTTON
			if(mouseOver(mx, my, 300, 533, 90, 45)) {
				if(!Game.muted) {
					AudioPlayer.getSound("click").play(1, 0.15f);
				}
				Game.gameState = Game.STATE.Stats;
				return;
			}
			// RIGHT BUTTON
			if(mouseOver(mx, my, 472, 533, 90, 45)) {
				if(!Game.muted) {
					AudioPlayer.getSound("click").play(1, 0.15f);
				}
				Game.gameState = Game.STATE.Upgrade;
				return;
			}
		}
		
		if(game.gameState == Game.STATE.Stats) {
			// NEXT DAY BUTTON
			if(mouseOver(mx, my, 405, 530, 50, 50)) {
				if(!Game.muted) {
					AudioPlayer.getSound("click").play(1, 0.15f);
				}
				Game.gameState = Game.STATE.Confirm;
				return;
			}
			// RIGHT BUTTON
			if(mouseOver(mx, my, 472, 533, 90, 45)) {
				if(!Game.muted) {
					AudioPlayer.getSound("click").play(1, 0.15f);
				}
				Game.gameState = Game.STATE.Menu;
				return;
			}
		}
		
		if(game.gameState == Game.STATE.Upgrade) {
			// NEXT DAY BUTTON
			if(mouseOver(mx, my, 405, 530, 50, 50) && UpgradeKeeper.upgradePage == 0) {
				if(!Game.muted) {
					AudioPlayer.getSound("click").play(1, 0.15f);
				}
				Game.gameState = Game.STATE.Confirm;
				return;
			}
			// BACK BUTTON
			if(mouseOver(mx, my, 405, 530, 50, 50) && UpgradeKeeper.upgradePage != 0) {
				if(!Game.muted) {
					AudioPlayer.getSound("click").play(1, 0.15f);
				}
				UpgradeKeeper.upgradePage = 0;
				hover1 = false;
				hover2 = false;
				hover3 = false;
				tooPoor = false;
				return;
			}
			// LEFT BUTTON
			if(mouseOver(mx, my, 300, 533, 90, 45)) {
				if(!Game.muted) {
					AudioPlayer.getSound("click").play(1, 0.15f);
				}
				Game.gameState = Game.STATE.Menu;
				hover1 = false;
				hover2 = false;
				hover3 = false;
				tooPoor = false;
			//	UpgradeKeeper.upgradePage = 0;
				return;
			}
			// BUTTON to INGREDIENT PAGE
			if(mouseOver(mx, my, 145, 160, 175, 350) && UpgradeKeeper.upgradePage == 0) {
				if(!Game.muted) {
					AudioPlayer.getSound("click").play(1, 0.15f);
				}
				UpgradeKeeper.upgradePage = 1;
				return;
			}
			// BUTTON to DECORATION PAGE
			if(mouseOver(mx, my, 345, 160, 175, 350) && UpgradeKeeper.upgradePage == 0) {
				if(!Game.muted) {
					AudioPlayer.getSound("click").play(1, 0.15f);
				}
				UpgradeKeeper.upgradePage = 4;
				return;
			}
			// BUTTON to GAMEPLAY PAGE
			if(mouseOver(mx, my, 545, 160, 175, 350) && UpgradeKeeper.upgradePage == 0) {
				if(!Game.muted) {
					AudioPlayer.getSound("click").play(1, 0.15f);
				}
				UpgradeKeeper.upgradePage = 6;
				return;
			}
			
			if(Game.gameState == Game.STATE.Upgrade && UpgradeKeeper.upgradePage == 1) {
				// <--- BUTTON FOR INGREDIENT pg. 1
				if(mouseOver(mx, my, 301, 330, 55, 30)) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					UpgradeKeeper.upgradePage = 3;
					hover1 = false;
					hover2 = false;
					hover3 = false;
					tooPoor = false;
					return;
				}
				// ---> BUTTON FOR INGREDIENT pg. 1
				if(mouseOver(mx, my, 515, 330, 55, 30)) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					UpgradeKeeper.upgradePage = 2;
					hover1 = false;
					hover2 = false;
					hover3 = false;
					tooPoor = false;
					return;
				}
				// UPGRADE BUTTON 1
				if(mouseOver(mx, my, 150, 180, 155, 120) && hover1 == false) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					hover1 = true;
					hover2 = false;
					hover3 = false;
					tooPoor = false;
				}
				// UPGRADE BUY 1
				if(mouseOver(mx, my, 615, 402, 65, 86) && UpgradeKeeper.uSauce < 3 && hover1 == true) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					if(HUD.money >= UpgradeKeeper.pSauce) {
						if(!Game.muted) {
							AudioPlayer.getSound("purchase").play(1, 0.2f);
						}
						HUD.money = HUD.money - UpgradeKeeper.pSauce;
						UpgradeKeeper.pSauce = UpgradeKeeper.pSauce + 100;
						UpgradeKeeper.saucePlus = UpgradeKeeper.saucePlus + 3;
						UpgradeKeeper.uSauce++;
					}
					else if(HUD.money < UpgradeKeeper.pSauce) {
						tooPoor = true;
						hover1 = false;
					}
				}
				// UPGRADE BUTTON 2
				if(mouseOver(mx, my, 358, 180, 155, 120) && hover2 == false) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					hover1 = false;
					hover2 = true;
					hover3 = false;
					tooPoor = false;
				}
				// UPGRADE BUY 2
				if(mouseOver(mx, my, 615, 402, 65, 86) && UpgradeKeeper.uMozz < 3 && hover2 == true) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					if(HUD.money >= UpgradeKeeper.pMozz) {
						if(!Game.muted) {
							AudioPlayer.getSound("purchase").play(1, 0.2f);
						}
						HUD.money = HUD.money - UpgradeKeeper.pMozz;
						UpgradeKeeper.pMozz = UpgradeKeeper.pMozz + 150;
						UpgradeKeeper.mozzPlus = UpgradeKeeper.mozzPlus + 3;
						UpgradeKeeper.uMozz++;
					}
					else if(HUD.money < UpgradeKeeper.pMozz) {
						tooPoor = true;
						hover2 = false;
					}
				}
				// UPGRADE BUTTON 3
				if(mouseOver(mx, my, 566, 180, 155, 120) && hover3 == false) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					hover1 = false;
					hover2 = false;
					hover3 = true;
					tooPoor = false;
				}
				// UPGRADE BUY 3
				if(mouseOver(mx, my, 615, 402, 65, 86) && UpgradeKeeper.uPepp < 3 && hover3 == true) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					if(HUD.money >= UpgradeKeeper.pPepp) {
						if(!Game.muted) {
							AudioPlayer.getSound("purchase").play(1, 0.2f);
						}
						HUD.money = HUD.money - UpgradeKeeper.pPepp;
						UpgradeKeeper.pPepp = UpgradeKeeper.pPepp + 150;
						UpgradeKeeper.peppPlus = UpgradeKeeper.peppPlus + 3;
						UpgradeKeeper.uPepp++;
					}
					else if(HUD.money < UpgradeKeeper.pPepp) {
						tooPoor = true;
						hover3 = false;
				}
			}
		}
			
			if(Game.gameState == Game.STATE.Upgrade && UpgradeKeeper.upgradePage == 2) {
				// <--- BUTTON FOR INGREDIENT pg. 2
				if(mouseOver(mx, my, 301, 330, 55, 30) && UpgradeKeeper.upgradePage == 2) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					UpgradeKeeper.upgradePage = 1;
					hover1 = false;
					hover2 = false;
					hover3 = false;
					tooPoor = false;
					return;
				}
				// ---> BUTTON FOR INGREDIENT pg. 2
				if(mouseOver(mx, my, 515, 330, 55, 30) && UpgradeKeeper.upgradePage == 2) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					UpgradeKeeper.upgradePage = 3;
					hover1 = false;
					hover2 = false;
					hover3 = false;
					tooPoor = false;
					return;
				}
				// UPGRADE BUTTON 1
				if(mouseOver(mx, my, 150, 180, 155, 120) && hover1 == false) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					hover1 = true;
					hover2 = false;
					hover3 = false;
					tooPoor = false;
				}
				// UPGRADE BUY 1
				if(mouseOver(mx, my, 615, 402, 65, 86) && UpgradeKeeper.uChed < 3 && hover1 == true) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					if(HUD.money >= UpgradeKeeper.pChed) {
						if(!Game.muted) {
							AudioPlayer.getSound("purchase").play(1, 0.2f);
						}
						HUD.money = HUD.money - UpgradeKeeper.pChed;
						UpgradeKeeper.pChed = UpgradeKeeper.pChed + 100;
						UpgradeKeeper.chedPlus = UpgradeKeeper.chedPlus + 4;
						UpgradeKeeper.uChed++;
					}
					else if(HUD.money < UpgradeKeeper.pChed) {
						tooPoor = true;
						hover1 = false;
					}
				}
				// UPGRADE BUTTON 2
				if(mouseOver(mx, my, 358, 180, 155, 120) && hover2 == false) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					hover1 = false;
					hover2 = true;
					hover3 = false;
					tooPoor = false;
				}
				// UPGRADE BUY 2
				if(mouseOver(mx, my, 615, 402, 65, 86) && UpgradeKeeper.uSaus < 3 && hover2 == true) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					if(HUD.money >= UpgradeKeeper.pSaus) {
						if(!Game.muted) {
							AudioPlayer.getSound("purchase").play(1, 0.2f);
						}
						HUD.money = HUD.money - UpgradeKeeper.pSaus;
						UpgradeKeeper.pSaus = UpgradeKeeper.pSaus + 150;
						UpgradeKeeper.sausPlus = UpgradeKeeper.sausPlus + 4;
						UpgradeKeeper.uSaus++;
					}
					else if(HUD.money < UpgradeKeeper.pSaus) {
						tooPoor = true;
						hover2 = false;
					}
				}
				// UPGRADE BUTTON 3
				if(mouseOver(mx, my, 566, 180, 155, 120) && hover3 == false) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					hover1 = false;
					hover2 = false;
					hover3 = true;
					tooPoor = false;
				}
				// UPGRADE BUY 3
				if(mouseOver(mx, my, 615, 402, 65, 86) && UpgradeKeeper.uMush < 3 && hover3 == true) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					if(HUD.money >= UpgradeKeeper.pMush) {
						if(!Game.muted) {
							AudioPlayer.getSound("purchase").play(1, 0.2f);
						}
						HUD.money = HUD.money - UpgradeKeeper.pMush;
						UpgradeKeeper.pMush = UpgradeKeeper.pMush + 150;
						UpgradeKeeper.mushPlus = UpgradeKeeper.mushPlus + 3;
						UpgradeKeeper.uMush++;
					}
					else if(HUD.money < UpgradeKeeper.pMush) {
						tooPoor = true;
						hover3 = false;
				}
			}
		}
			
			if(Game.gameState == Game.STATE.Upgrade && UpgradeKeeper.upgradePage == 3) {
				// <--- BUTTON FOR INGREDIENT pg. 3
				if(mouseOver(mx, my, 301, 330, 55, 30) && UpgradeKeeper.upgradePage == 3) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					UpgradeKeeper.upgradePage = 2;
					hover1 = false;
					hover2 = false;
					hover3 = false;
					tooPoor = false;
					return;
				}
				// ---> BUTTON FOR INGREDIENT pg. 3
				if(mouseOver(mx, my, 515, 330, 55, 30) && UpgradeKeeper.upgradePage == 3) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					UpgradeKeeper.upgradePage = 1;
					hover1 = false;
					hover2 = false;
					hover3 = false;
					tooPoor = false;
					return;
				}	
				// UPGRADE BUTTON 1
				if(mouseOver(mx, my, 150, 180, 155, 120) && hover1 == false) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					hover1 = true;
					hover2 = false;
					hover3 = false;
					tooPoor = false;
				}
				// UPGRADE BUY 1
				if(mouseOver(mx, my, 615, 402, 65, 86) && UpgradeKeeper.uOnion < 3 && hover1 == true) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					if(HUD.money >= UpgradeKeeper.pOnion) {
						if(!Game.muted) {
							AudioPlayer.getSound("purchase").play(1, 0.2f);
						}
						HUD.money = HUD.money - UpgradeKeeper.pOnion;
						UpgradeKeeper.pOnion = UpgradeKeeper.pOnion + 200;
						UpgradeKeeper.onionPlus = UpgradeKeeper.onionPlus + 4;
						UpgradeKeeper.uOnion++;
					}
					else if(HUD.money < UpgradeKeeper.pOnion) {
						tooPoor = true;
						hover1 = false;
					}
				}
				// UPGRADE BUTTON 2
				if(mouseOver(mx, my, 358, 180, 155, 120) && hover2 == false) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					hover1 = false;
					hover2 = true;
					hover3 = false;
					tooPoor = false;
				}
				// UPGRADE BUY 2
				if(mouseOver(mx, my, 615, 402, 65, 86) && UpgradeKeeper.uOlive < 3 && hover2 == true) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					if(HUD.money >= UpgradeKeeper.pOlive) {
						if(!Game.muted) {
							AudioPlayer.getSound("purchase").play(1, 0.2f);
						}
						HUD.money = HUD.money - UpgradeKeeper.pOlive;
						UpgradeKeeper.pOlive = UpgradeKeeper.pOlive + 200;
						UpgradeKeeper.olivePlus = UpgradeKeeper.olivePlus + 4;
						UpgradeKeeper.uOlive++;
					}
					else if(HUD.money < UpgradeKeeper.pOlive) {
						tooPoor = true;
						hover2 = false;
					}
				}
				// UPGRADE BUTTON 3
				if(mouseOver(mx, my, 566, 180, 155, 120) && hover3 == false) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					hover1 = false;
					hover2 = false;
					hover3 = true;
					tooPoor = false;
				}
				// UPGRADE BUY 3
				if(mouseOver(mx, my, 615, 402, 65, 86) && UpgradeKeeper.uSpin < 3 && hover3 == true) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					if(HUD.money >= UpgradeKeeper.pSpin) {
						if(!Game.muted) {
							AudioPlayer.getSound("purchase").play(1, 0.2f);
						}
						HUD.money = HUD.money - UpgradeKeeper.pSpin;
						UpgradeKeeper.pSpin = UpgradeKeeper.pSpin + 250;
						UpgradeKeeper.spinPlus = UpgradeKeeper.spinPlus + 5;
						UpgradeKeeper.uSpin++;
					}
					else if(HUD.money < UpgradeKeeper.pSpin) {
						tooPoor = true;
						hover3 = false;
				}
			}
		}
			
			if(Game.gameState == Game.STATE.Upgrade && UpgradeKeeper.upgradePage == 4) {
				// <--- BUTTON FOR DECORATION pg. 2
				if(mouseOver(mx, my, 301, 330, 55, 30)) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					UpgradeKeeper.upgradePage = 5;
					hover1 = false;
					hover2 = false;
					hover3 = false;
					tooPoor = false;
					return;
				}
				// ---> BUTTON FOR INGREDIENT pg. 2
				if(mouseOver(mx, my, 515, 330, 55, 30)) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					UpgradeKeeper.upgradePage = 5;
					hover1 = false;
					hover2 = false;
					hover3 = false;
					tooPoor = false;
					return;
				}
				// UPGRADE BUTTON 1
				if(mouseOver(mx, my, 150, 180, 155, 120) && hover1 == false) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					hover1 = true;
					hover2 = false;
					hover3 = false;
					tooPoor = false;
				}
				// UPGRADE BUY 1
				if(mouseOver(mx, my, 615, 402, 65, 86) && UpgradeKeeper.lampsBought < 1 && hover1 == true) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					if(HUD.money >= UpgradeKeeper.pLamps) {
						if(!Game.muted) {
							AudioPlayer.getSound("purchase").play(1, 0.2f);
						}
						HUD.money = HUD.money - UpgradeKeeper.pLamps;
						UpgradeKeeper.lampsBought++;
					}
					else if(HUD.money < UpgradeKeeper.pLamps) {
						tooPoor = true;
						hover1 = false;
					}
				}
				// UPGRADE BUTTON 2
				if(mouseOver(mx, my, 358, 180, 155, 120) && hover2 == false) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					hover1 = false;
					hover2 = true;
					hover3 = false;
					tooPoor = false;
				}
				// UPGRADE BUY 2
				if(mouseOver(mx, my, 615, 402, 65, 86) && UpgradeKeeper.poster1Bought < 1 && hover2 == true) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					if(HUD.money >= UpgradeKeeper.pPoster1) {
						if(!Game.muted) {
							AudioPlayer.getSound("purchase").play(1, 0.2f);
						}
						HUD.money = HUD.money - UpgradeKeeper.pPoster1;
						UpgradeKeeper.poster1Bought++;
					}
					else if(HUD.money < UpgradeKeeper.pPoster1) {
						tooPoor = true;
						hover2 = false;
					}
				}
				// UPGRADE BUTTON 3
				if(mouseOver(mx, my, 566, 180, 155, 120) && hover3 == false) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					hover1 = false;
					hover2 = false;
					hover3 = true;
					tooPoor = false;
				}
				// UPGRADE BUY 3
				if(mouseOver(mx, my, 615, 402, 65, 86) && UpgradeKeeper.wallpaperBought < 1 && hover3 == true) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					if(HUD.money >= UpgradeKeeper.pWallpaper) {
						if(!Game.muted) {
							AudioPlayer.getSound("purchase").play(1, 0.2f);
						}
						HUD.money = HUD.money - UpgradeKeeper.pWallpaper;
						UpgradeKeeper.wallpaperBought++;
					}
					else if(HUD.money < UpgradeKeeper.pWallpaper) {
						tooPoor = true;
						hover3 = false;
				}
			}
		}
			if(Game.gameState == Game.STATE.Upgrade && UpgradeKeeper.upgradePage == 5) {
				// <--- BUTTON FOR DECORATION pg. 2
				if(mouseOver(mx, my, 301, 330, 55, 30)) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					UpgradeKeeper.upgradePage = 4;
					hover1 = false;
					hover2 = false;
					hover3 = false;
					tooPoor = false;
					return;
				}
				// ---> BUTTON FOR INGREDIENT pg. 1
				if(mouseOver(mx, my, 515, 330, 55, 30)) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					UpgradeKeeper.upgradePage = 4;
					hover1 = false;
					hover2 = false;
					hover3 = false;
					tooPoor = false;
					return;
				}
				// UPGRADE BUTTON 1
				if(mouseOver(mx, my, 150, 180, 155, 120) && hover1 == false) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					hover1 = true;
					hover2 = false;
					hover3 = false;
					tooPoor = false;
				}
				// UPGRADE BUY 1
				if(mouseOver(mx, my, 615, 402, 65, 86) && UpgradeKeeper.doorbellBought < 1 && hover1 == true) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					if(HUD.money >= UpgradeKeeper.pDoorbell) {
						if(!Game.muted) {
							AudioPlayer.getSound("purchase").play(1, 0.2f);
						}
						HUD.money = HUD.money - UpgradeKeeper.pDoorbell;
						UpgradeKeeper.doorbellBought++;
					}
					else if(HUD.money < UpgradeKeeper.pDoorbell) {
						tooPoor = true;
						hover1 = false;
					}
				}
				// UPGRADE BUTTON 2
				if(mouseOver(mx, my, 358, 180, 155, 120) && hover2 == false) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					hover1 = false;
					hover2 = true;
					hover3 = false;
					tooPoor = false;
				}
				// UPGRADE BUY 2
				if(mouseOver(mx, my, 615, 402, 65, 86) && UpgradeKeeper.poster2Bought < 1 && hover2 == true) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					if(HUD.money >= UpgradeKeeper.pPoster2) {
						if(!Game.muted) {
							AudioPlayer.getSound("purchase").play(1, 0.2f);
						}
						HUD.money = HUD.money - UpgradeKeeper.pPoster2;
						UpgradeKeeper.poster2Bought++;
					}
					else if(HUD.money < UpgradeKeeper.pPoster2) {
						tooPoor = true;
						hover2 = false;
					}
				}
				// UPGRADE BUTTON 3
				if(mouseOver(mx, my, 566, 180, 155, 120) && hover3 == false) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					hover1 = false;
					hover2 = false;
					hover3 = true;
					tooPoor = false;
				}
				// UPGRADE BUY 3
				if(mouseOver(mx, my, 615, 402, 65, 86) && UpgradeKeeper.plantsBought < 1 && hover3 == true) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					if(HUD.money >= UpgradeKeeper.pPlants) {
						if(!Game.muted) {
							AudioPlayer.getSound("purchase").play(1, 0.2f);
						}
						HUD.money = HUD.money - UpgradeKeeper.pPlants;
						UpgradeKeeper.plantsBought++;
					}
					else if(HUD.money < UpgradeKeeper.pPlants) {
						tooPoor = true;
						hover3 = false;
				}
			}
		}
			if(Game.gameState == Game.STATE.Upgrade && UpgradeKeeper.upgradePage == 6) {
				// UPGRADE BUTTON 1
				if(mouseOver(mx, my, 150, 180, 155, 120) && hover1 == false) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					hover1 = true;
					hover2 = false;
					hover3 = false;
					tooPoor = false;
				}
				// UPGRADE BUY 1
				if(mouseOver(mx, my, 615, 402, 65, 86) && UpgradeKeeper.gDayTime < 2 && hover1 == true) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					if(HUD.money >= UpgradeKeeper.pDaytime) {
						if(!Game.muted) {
							AudioPlayer.getSound("purchase").play(1, 0.2f);
						}
						HUD.money = HUD.money - UpgradeKeeper.pDaytime;
						UpgradeKeeper.pDaytime = UpgradeKeeper.pDaytime + 325;
						UpgradeKeeper.daytimePlus = UpgradeKeeper.daytimePlus - 0.0055575f;
						UpgradeKeeper.gDayTime++;
					}
					else if(HUD.money < UpgradeKeeper.pDaytime) {
						tooPoor = true;
						hover1 = false;
					}
				}
				// UPGRADE BUTTON 2
				if(mouseOver(mx, my, 358, 180, 155, 120) && hover2 == false) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					hover1 = false;
					hover2 = true;
					hover3 = false;
					tooPoor = false;
				}
				// UPGRADE BUY 2
				if(mouseOver(mx, my, 615, 402, 65, 86) && UpgradeKeeper.gCookTime < 2 && hover2 == true) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					if(HUD.money >= UpgradeKeeper.pCookTime) {
						if(!Game.muted) {
							AudioPlayer.getSound("purchase").play(1, 0.2f);
						}
						HUD.money = HUD.money - UpgradeKeeper.pCookTime;
						UpgradeKeeper.pCookTime = UpgradeKeeper.pCookTime + 350;
						UpgradeKeeper.cooktimeMinus = UpgradeKeeper.cooktimeMinus + 15;
						UpgradeKeeper.gCookTime++;
					}
					else if(HUD.money < UpgradeKeeper.pCookTime) {
						tooPoor = true;
						hover2 = false;
					}
				}
				// UPGRADE BUTTON 3
				if(mouseOver(mx, my, 566, 180, 155, 120) && hover3 == false) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					hover1 = false;
					hover2 = false;
					hover3 = true;
					tooPoor = false;
				}
				// UPGRADE BUY 3
				if(mouseOver(mx, my, 615, 402, 65, 86) && UpgradeKeeper.gMoneyMul < 2 && hover3 == true) {
					if(!Game.muted) {
						AudioPlayer.getSound("click").play(1, 0.15f);
					}
					if(HUD.money >= UpgradeKeeper.pMoneyMul) {
						if(!Game.muted) {
							AudioPlayer.getSound("purchase").play(1, 0.2f);
						}
						HUD.money = HUD.money - UpgradeKeeper.pMoneyMul;
						UpgradeKeeper.pMoneyMul = UpgradeKeeper.pMoneyMul + 500;
						UpgradeKeeper.moneyMultiplier = UpgradeKeeper.moneyMultiplier + 1;
						UpgradeKeeper.gMoneyMul++;
					}
					else if(HUD.money < UpgradeKeeper.pMoneyMul) {
						tooPoor = true;
						hover3 = false;
				}
			}
		}
	}
		
		if(Game.gameState == Game.STATE.Confirm) {
			// CANCEL BUTTON
			if(mouseOver(mx, my, 405, 530, 50, 50)) {
				if(!Game.muted) {
					AudioPlayer.getSound("click").play(1, 0.15f);
				}
				Game.gameState = Game.STATE.Menu;
				return;
			}
			// CONFIRM BUTTON
			if(mouseOver(mx, my, 310, 440, 240, 64)) {
				if(!Game.muted) {
					AudioPlayer.getMusic("endMusic").stop();
					AudioPlayer.getSound("click").play(1, 0.15f);
				}
				handler.clearParticles();
				Spawn.timeKeep = 0;
				GameDisplay.timer = 0;
				UpgradeKeeper.upgradePage = 0;
				Game.gameState = Game.STATE.Game;
				GameDisplay.displayState = GameDisplay.STATE.DayCounter;
			}
		}
		
		// MUTE BUTTON
		if(mouseOver(mx, my, 3, 5, 58, 58)) {
			String currentSong = "";
			if(Game.gameState == Game.STATE.Main || Game.gameState == Game.STATE.Help || Game.gameState == Game.STATE.Credits) {
				currentSong = "mainMusic";
			}
			else if(Game.gameState == Game.STATE.Game) {
				currentSong = "epicMusic";
			}
			else if(Game.gameState == Game.STATE.End || Game.gameState == Game.STATE.Confirm || Game.gameState == Game.STATE.Menu || Game.gameState == Game.STATE.Upgrade || Game.gameState == Game.STATE.Stats) {
				currentSong = "endMusic";
			}
			
			if(!Game.muted) {
				if(!Game.muted) {
					AudioPlayer.getSound("click").play(1, 0.15f);
				}
				Game.muted = true;
				AudioPlayer.getMusic(currentSong).stop();
				AudioPlayer.getSound("ovenHum").stop();
				return;
			}
			else {
				AudioPlayer.getSound("click").play(1, 0.15f);
				Game.muted = false;
				AudioPlayer.getMusic(currentSong).loop(1, 0.1f);
				return;
			}
		}
	}
	
	public void mouseReleased(MouseEvent e) {

	}
	
	private boolean mouseOver(int mx, int my, int x, int y, int width, int height) {
		if(mx > x && mx < x + width) {
			if (my > y && my < y + height) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	
	public void tick() {
		timer++;
			
		if(timer == 100 && scoreShowing == true) {
			score = 0;
			scoreShowing = false;
			
			Spawn.daveSpawn = 0;
			Spawn.billSpawn = 0;
			Spawn.clintSpawn = 0;
			Spawn.annaSpawn = 0;
			Spawn.paulaSpawn = 0;
			Spawn.jacksonSpawn = 0;
			Spawn.sherylSpawn = 0;
			Spawn.charlieSpawn = 0;
			Spawn.maxwellSpawn = 0;
			Spawn.brucieSpawn = 0;
			
			GameDisplay.dough = 0;
			GameDisplay.sauce = 0;
			GameDisplay.mozz = 0;
			GameDisplay.ched = 0;
			GameDisplay.pepp = 0;
			GameDisplay.saus = 0;
			GameDisplay.mush = 0;
			GameDisplay.onion = 0;
			GameDisplay.olives = 0;
			GameDisplay.spin = 0;
			GameDisplay.isCooked = 0;
			GameDisplay.isCut = 0;
			
			handler.clearCustomers();
			Spawn.timeKeep = 0;
		}
	}
	
	@SuppressWarnings("unused")
	public void render(Graphics g) {
		
		Toolkit k = Toolkit.getDefaultToolkit();
	//	Image ingredientLogo = k.getImage("res/images/ingredientLogo.png");
	//	Image decorationLogo = k.getImage("res/images/lampLogo.png");
	//	Image gameplayLogo = k.getImage("res/images/controllerLogo.png");
		
		Image ingredientLogo = k.getImage(getClass().getClassLoader().getResource("images/ingredientLogo.png"));
		Image decorationLogo = k.getImage(getClass().getClassLoader().getResource("images/lampLogo.png"));
		Image gameplayLogo = k.getImage(getClass().getClassLoader().getResource("images/controllerLogo.png"));
		
		if(Game.gameState == Game.STATE.Main) {
			Font f  = new Font("Haettenschweiler", Font.PLAIN, 90);
			Font f2 = new Font("Franklin Gothic Medium", Font.PLAIN, 40);
			Font f3 = new Font("Franklin Gothic Medium", Font.PLAIN, 12);
			
			g.setFont(f);
			g.setColor(Color.BLACK);
			g.drawString("Perfection Pizza", 208, 130);
			g.setColor(Color.WHITE);
			g.drawString("Perfection Pizza", 203, 125);
			
			g.setFont(f2);
			g.setColor(Color.BLACK);
			g.drawRect((int) (Game.WIDTH / 3) + 15, 310, 240, 64);
			g.drawString("Play", 399, 355);
			g.setColor(Color.WHITE);
			g.drawRect((int) (Game.WIDTH / 3) + 14, 309, 240, 64);
			g.drawString("Play", 397, 353);
			
			g.setColor(Color.BLACK);
			g.drawRect((int) (Game.WIDTH / 3) + 15, 410, 240, 64);
			g.drawString("Help", 399, 455);
			g.setColor(Color.WHITE);
			g.drawRect((int) (Game.WIDTH / 3) + 14, 409, 240, 64);
			g.drawString("Help", 397, 453);
			
			g.setColor(Color.BLACK);
			g.drawRect((int) (Game.WIDTH / 3) + 15, 510, 240, 64);
			g.drawString("Quit", 399, 555);
			g.setColor(Color.WHITE);
			g.drawRect((int) (Game.WIDTH / 3) + 14, 509, 240, 64);
			g.drawString("Quit", 397, 553);
			
			g.setFont(f3);
			g.setColor(Color.BLACK);
			g.drawString("� Vicious Games, Reid Cruzan, 2021-22", 332, 635);
			
			g.setColor(Color.ORANGE.darker().darker());
			g.fillRoundRect(375, 159, 120, 120, 120, 120);
			g.setColor(Color.ORANGE);
			g.fillRoundRect(380, 164, 110, 110, 110, 110);
			g.setColor(Color.YELLOW);
			g.fillRoundRect(385, 169, 100, 100, 100, 100);
			
			g.setColor(Color.RED.darker());
			g.fillRoundRect(391, 195, 15, 15, 15, 15);
			g.fillRoundRect(438, 170, 15, 15, 15, 15);
			g.fillRoundRect(453, 195, 15, 15, 15, 15);
			g.fillRoundRect(415, 200, 15, 15, 15, 15);
			g.fillRoundRect(458, 225, 15, 15, 15, 15);
			g.fillRoundRect(413, 250, 15, 15, 15, 15);
			g.fillRoundRect(393, 225, 15, 15, 15, 15);
			g.fillRoundRect(438, 240, 15, 15, 15, 15);
					
			g.setColor(Color.BLACK);
			g.drawRoundRect(375, 159, 120, 120, 120, 120);
			g.drawRoundRect(380, 164, 110, 110, 110, 110);
			g.drawRoundRect(391, 195, 15, 15, 15, 15);
			g.drawRoundRect(438, 170, 15, 15, 15, 15);
			g.drawRoundRect(453, 195, 15, 15, 15, 15);
			g.drawRoundRect(415, 200, 15, 15, 15, 15);
			g.drawRoundRect(458, 225, 15, 15, 15, 15);
			g.drawRoundRect(413, 250, 15, 15, 15, 15);
			g.drawRoundRect(393, 225, 15, 15, 15, 15);
			g.drawRoundRect(438, 240, 15, 15, 15, 15);
			
			g.drawLine(375, 220, 495, 220);
			g.drawLine(435, 160, 435, 280);
			g.drawLine(390, 182, 480, 258);
			g.drawLine(390, 258, 480, 182);
			
	}
		
		else if(Game.gameState == Game.STATE.Help) {
			Font f  = new Font("Haettenschweiler", Font.PLAIN, 90);
			Font f2 = new Font("Franklin Gothic Medium", Font.PLAIN, 40);
			Font f3 = new Font("Franklin Gothic Medium", Font.PLAIN, 12);
			Font f4 = new Font("Franklin Gothic Medium", Font.PLAIN, 18);
			
			g.setFont(f);
			g.setColor(Color.BLACK);
			g.drawString("HELP", 380, 130);
			g.setColor(Color.WHITE);
			g.drawString("HELP", 375, 125);
			
			g.setFont(f2);
			g.setColor(Color.BLACK);
			g.drawRect((int) (Game.WIDTH / 3) + 15, 510, 240, 64);
			g.drawString("Back", 393, 555);
			g.setColor(Color.WHITE);
			g.drawRect((int) (Game.WIDTH / 3) + 14, 509, 240, 64);
			g.drawString("Back", 391, 553);
			
			g.setFont(f4);
			g.setColor(Color.BLACK);
			g.drawString("You have just inherited a pizza store from your late Uncle Vinny.", 195, 180);
			g.drawString("Cook and serve fresh pizza pies to customers by clicking on ingredients.", 167, 205);
			g.drawString("Satisfied customers equals a satisfied wallet, which allows you to buy new", 160, 230);
			g.drawString("ingredients and upgrades to cook better pizzas. Pre-heat those ovens!", 175, 255);
			
			g.drawString("Your goal is to run the pizzeria for 30 days while staying out of", 206, 305);
			g.drawString("financial debt. Should you lose enough money, or stay in debt long enough,", 157, 330);
			g.drawString("the pizzeria shall file for bankruptcy and it'll be game over for you.", 196, 355);
			g.drawString("Can you keep the legacy alive?", 315, 412);
			
			g.setFont(f2);
			g.drawString("LET'S COOK!", 328, 462);
			g.setColor(Color.WHITE);
			g.drawString("LET'S COOK!", 326, 460);
			
			g.setFont(f3);
			g.setColor(Color.BLACK);
			g.drawString("� Vicious Games, Reid Cruzan, 2021-22", 332, 635);
		}
		
		else if(Game.gameState == Game.STATE.Credits) {
			Font f  = new Font("Haettenschweiler", Font.PLAIN, 90);
			Font f2 = new Font("Franklin Gothic Medium", Font.PLAIN, 40);
			Font f3 = new Font("Franklin Gothic Medium", Font.PLAIN, 12);
			Font f4  = new Font("Haettenschweiler", Font.PLAIN, 48);
			Font f5 = new Font("Franklin Gothic Medium", Font.PLAIN, 32);
			
			g.setFont(f);
			g.setColor(Color.BLACK);
			g.drawString("CREDITS", 332, 130);
			g.setColor(Color.WHITE);
			g.drawString("CREDITS", 327, 125);
			
			g.setFont(f4);
			g.setColor(Color.BLACK);
			g.drawString("Coding, Music and Design", 252, 232);
			g.drawString("Special Thanks", 328, 383);
			g.setColor(Color.WHITE);
			g.drawString("Coding, Music and Design", 250, 230);
			g.drawString("Special Thanks", 326, 381);
			
			g.setFont(f2);
			g.setColor(Color.BLACK);
			g.drawRect((int) (Game.WIDTH / 3) + 15, 510, 240, 64);
			g.drawString("Back", 393, 555);
			g.setColor(Color.WHITE);
			g.drawRect((int) (Game.WIDTH / 3) + 14, 509, 240, 64);
			g.drawString("Back", 391, 553);
			
			g.setFont(f5);
			g.setColor(Color.BLACK);
			g.drawString("Reid Cruzan", 350, 280);
			g.drawString("To Me, Myself and I", 304, 431);
			
			g.setFont(f3);
			g.setColor(Color.BLACK);
			g.drawString("� Vicious Games, Reid Cruzan, 2021-22", 332, 635);
		}
		
		else if(Game.gameState == Game.STATE.Menu) {
			Font f  = new Font("Haettenschweiler", Font.PLAIN, 90);
			Font f2 = new Font("Franklin Gothic Medium", Font.PLAIN, 40);
			Font f3 = new Font("Franklin Gothic Medium", Font.PLAIN, 12);
			Font f4 = new Font("Franklin Gothic Medium", Font.BOLD, 28);
			Font f5 = new Font("Franklin Gothic Medium", Font.BOLD, 18);
			
			g.setFont(f);
			g.setColor(Color.BLACK);
			g.drawString("MENU", 362, 130);
			g.setColor(Color.WHITE);
			g.drawString("MENU", 357, 125);
			
			g.setColor(Color.ORANGE.darker());
			g.fillRect(306, 156, 250, 350);
			
			g.setFont(f2);
			g.setColor(Color.BLACK);
			g.drawRect(406, 531, 50, 50); // X BUTTON
			g.drawRect(301, 534, 90, 45); // LEFT BUTTON
			g.drawRect(473, 534, 90, 45); // RIGHT BUTTON
			g.drawRect(306, 156, 250, 350); // MAIN BOX
			
			g.drawString("X", 421, 570);
			g.drawString(">", 531, 570);
			g.drawString("<", 310, 570);
			g.drawString("___", 487, 553); // RIGHT
			g.drawString("___", 317, 553); // LEFT
			
			g.setColor(Color.WHITE);
			g.drawRect(405, 530, 50, 50); // X BUTTON
			g.drawRect(300, 533, 90, 45); // LEFT BUTTON
			g.drawRect(472, 533, 90, 45); // RIGHT BUTTON
			g.drawRect(305, 155, 250, 350); // MAIN BOX
			
			g.drawString("X", 420, 569);
			g.drawString(">", 530, 569);
			g.drawString("<", 309, 569);
			g.drawString("___", 486, 552); // RIGHT
			g.drawString("___", 316, 552); // LEFT
			
			g.setFont(f4);
			if((HUD.getDay() - 1) <= 9) {
				g.setColor(Color.BLACK);
				g.drawString("Day " + (HUD.getDay() - 1), 395, 236);
				g.drawString("Money", 389, 374);
				
				g.setColor(Color.WHITE);
				g.drawString("Day " + (HUD.getDay() - 1), 393, 234);
				g.drawString("Money", 387, 372);
			}
			else {
				g.setColor(Color.BLACK);
				g.drawString("Day " + (HUD.getDay() - 1), 386, 236);
				g.drawString("Money", 389, 374);
				
				g.setColor(Color.WHITE);
				g.drawString("Day " + (HUD.getDay() - 1), 384, 234);
				g.drawString("Money", 387, 372);
			}
			
			
			g.setFont(f5);
			g.setColor(Color.BLACK);
			g.drawString("COMPLETE!", 386, 275);
			
			if(HUD.getMoney() <= 1000) {
				g.drawString("$" + HUD.getMoney(), 407, 410);
			}
			else if(HUD.getMoney() >= 1000 && HUD.getMoney() < 10000) {
				g.drawString("$" + HUD.getMoney(), 402, 410);
			}
			else if(HUD.getMoney() >= 10000) {
				g.drawString("$" + HUD.getMoney(), 397, 410);
			}
			
			
			g.setFont(f3);
			g.setColor(Color.BLACK);
			g.drawString("� Vicious Games, Reid Cruzan, 2021-22", 332, 635);
		}
		
		else if(Game.gameState == Game.STATE.Stats) {
			Font f  = new Font("Haettenschweiler", Font.PLAIN, 90);
			Font f2 = new Font("Franklin Gothic Medium", Font.PLAIN, 40);
			Font f3 = new Font("Franklin Gothic Medium", Font.PLAIN, 12);
			Font f4 = new Font("Franklin Gothic Medium", Font.BOLD, 18);
			
			g.setFont(f2);
			g.setColor(Color.BLACK);
			g.drawRect(406, 531, 50, 50); // X BUTTON
			g.drawRect(473, 534, 90, 45); // RIGHT BUTTON
			
			g.drawString("X", 421, 570);
			g.drawString(">", 531, 570);
			g.drawString("___", 487, 553); // RIGHT
			
			g.setColor(Color.WHITE);
			g.drawRect(405, 530, 50, 50); // X BUTTON
			g.drawRect(472, 533, 90, 45); // RIGHT BUTTON
			
			g.drawString("X", 420, 569);
			g.drawString(">", 530, 569);
			g.drawString("___", 486, 552); // RIGHT
			
			g.setColor(Color.ORANGE.darker());
			g.fillRect(170, 165, 525, 300);
			g.setColor(Color.BLACK);
			g.drawRect(170, 165, 525, 300);
			g.setColor(Color.WHITE);
			g.drawRect(169, 164, 525, 300);
			
			g.setFont(f4);
			g.setColor(Color.BLACK);
			g.drawString("DAY", 414, 513);
			g.drawString("$", 106, 314);
			g.setColor(Color.WHITE);
			g.drawString("DAY", 413, 512);
			g.drawString("$", 105, 313);
			
			g.setFont(f3);
			g.setColor(Color.BLACK);
			// $
			g.drawString("0", 155, 464);
			g.drawString("625", 145, 389);
			g.drawString("1,250", 135, 313);
			g.drawString("1,975", 135, 240);
			g.drawString("2,500", 135, 173);
			// DAY
			g.drawString("0", 170, 482);
			g.drawString("5", 252, 482);
			g.drawString("10", 334, 482);
			g.drawString("15", 425, 482);
			g.drawString("20", 515, 482);
			g.drawString("25", 597, 482);
			g.drawString("30", 681, 482);
			
			g.setColor(Color.ORANGE.darker().darker());
			g.drawLine(252, 463, 252, 166);
			g.drawLine(340, 463, 340, 166);
			g.drawLine(431, 463, 431, 166);
			g.drawLine(521, 463, 521, 166);
			g.drawLine(603, 463, 603, 166);
			
			g.setColor(Color.WHITE);				// X VALUE GOES UP 17 PER DAY
			//     g.drawLine(171, 463, 187, 463 - (625 / 8));
							g.drawLine(171, 463, 171 + (17*1), 463 - StatKeeper.d1);
			g.drawLine(171 + (17*1), 463 - StatKeeper.d1, 171 + (17*2), 463 - StatKeeper.d2);
			g.drawLine(171 + (17*2), 463 - StatKeeper.d2, 171 + (17*3), 463 - StatKeeper.d3);
			g.drawLine(171 + (17*3), 463 - StatKeeper.d3, 171 + (17*4), 463 - StatKeeper.d4);
			g.drawLine(171 + (17*4), 463 - StatKeeper.d4, 171 + (17*5), 463 - StatKeeper.d5);
			g.drawLine(171 + (17*5), 463 - StatKeeper.d5, 171 + (17*6), 463 - StatKeeper.d6);
			g.drawLine(171 + (17*6), 463 - StatKeeper.d6, 171 + (17*7), 463 - StatKeeper.d7);
			g.drawLine(171 + (17*7), 463 - StatKeeper.d7, 171 + (17*8), 463 - StatKeeper.d8);
			g.drawLine(171 + (17*8), 463 - StatKeeper.d8, 171 + (17*9), 463 - StatKeeper.d9);
			g.drawLine(171 + (17*9), 463 - StatKeeper.d9, 175 + (17*10), 463 - StatKeeper.d10);
			g.drawLine(175 + (17*10), 463 - StatKeeper.d10, 171 + (17*11), 463 - StatKeeper.d11);
			g.drawLine(171 + (17*11), 463 - StatKeeper.d11, 171 + (17*12), 463 - StatKeeper.d12);
			g.drawLine(171 + (17*12), 463 - StatKeeper.d12, 171 + (17*13), 463 - StatKeeper.d13);
			g.drawLine(171 + (17*13), 463 - StatKeeper.d13, 171 + (17*14), 463 - StatKeeper.d14);
			g.drawLine(171 + (17*14), 463 - StatKeeper.d14, 177 + (17*15), 463 - StatKeeper.d15);
			g.drawLine(177 + (17*15), 463 - StatKeeper.d15, 171 + (17*16), 463 - StatKeeper.d16);
			g.drawLine(171 + (17*16), 463 - StatKeeper.d16, 171 + (17*17), 463 - StatKeeper.d17);
			g.drawLine(171 + (17*17), 463 - StatKeeper.d17, 171 + (17*18), 463 - StatKeeper.d18);
			g.drawLine(171 + (17*18), 463 - StatKeeper.d18, 171 + (17*19), 463 - StatKeeper.d19);
			g.drawLine(171 + (17*19), 463 - StatKeeper.d19, 179 + (17*20), 463 - StatKeeper.d20);
			g.drawLine(179 + (17*20), 463 - StatKeeper.d20, 171 + (17*21), 463 - StatKeeper.d21);
			g.drawLine(171 + (17*21), 463 - StatKeeper.d21, 171 + (17*22), 463 - StatKeeper.d22);
			g.drawLine(171 + (17*22), 463 - StatKeeper.d22, 171 + (17*23), 463 - StatKeeper.d23);
			g.drawLine(171 + (17*23), 463 - StatKeeper.d23, 171 + (17*24), 463 - StatKeeper.d24);
			g.drawLine(171 + (17*24), 463 - StatKeeper.d24, 181 + (17*25), 463 - StatKeeper.d25);
			g.drawLine(181 + (17*25), 463 - StatKeeper.d25, 171 + (17*26), 463 - StatKeeper.d26);
			g.drawLine(171 + (17*26), 463 - StatKeeper.d26, 171 + (17*27), 463 - StatKeeper.d27);
			g.drawLine(171 + (17*27), 463 - StatKeeper.d27, 171 + (17*28), 463 - StatKeeper.d28);
			g.drawLine(171 + (17*28), 463 - StatKeeper.d28, 171 + (17*29), 463 - StatKeeper.d29);
			g.drawLine(171 + (17*29), 463 - StatKeeper.d29, 183 + (17*30), 463 - StatKeeper.d30);
			
			g.setColor(Color.ORANGE);
			g.fillRect(170, 0, 525, 164);
			
			g.setFont(f);
			g.setColor(Color.BLACK);
			g.drawString("STATS", 347, 130);
			g.setColor(Color.WHITE);
			g.drawString("STATS", 342, 125);
			
			g.setFont(f3);
			g.setColor(Color.BLACK);
			g.drawString("� Vicious Games, Reid Cruzan, 2021-22", 332, 635);
		}
		
		else if(Game.gameState == Game.STATE.Upgrade) {
			Font f  = new Font("Haettenschweiler", Font.PLAIN, 90);
			Font f2 = new Font("Franklin Gothic Medium", Font.PLAIN, 40);
			Font f3 = new Font("Franklin Gothic Medium", Font.PLAIN, 12);
			Font f4 = new Font("Franklin Gothic Medium", Font.BOLD, 28);
			Font f5 = new Font("Franklin Gothic Medium", Font.BOLD, 18);
			Font f6 = new Font("Franklin Gothic Medium", Font.PLAIN, 14);
			
			g.setFont(f);
			g.setColor(Color.BLACK);
			g.drawString("UPGRADES", 295, 130);
			g.setColor(Color.WHITE);
			g.drawString("UPGRADES", 290, 125);

			g.setColor(Color.BLACK);
			g.drawRect(406, 531, 50, 50); // X/BACK BUTTON
			g.drawRect(301, 534, 90, 45); // LEFT BUTTON
			
			if(UpgradeKeeper.upgradePage != 0) {
				g.setFont(f5);
				g.drawString("B", 409, 563);
				g.drawString("A", 420, 563);
				g.drawString("C", 432, 563);
				g.drawString("K", 442, 563);
			}
			else {
				g.setFont(f2);
				g.drawString("X", 421, 570);
			}
			
			g.setFont(f2);
			g.drawString("<", 310, 570);
			g.drawString("___", 317, 553); // LEFT
			
			g.setColor(Color.WHITE);
			g.drawRect(405, 530, 50, 50); // X/BACK BUTTON
			g.drawRect(300, 533, 90, 45); // LEFT BUTTON
			
			if(UpgradeKeeper.upgradePage != 0) {
				g.setFont(f5);
				g.drawString("B", 408, 562);
				g.drawString("A", 419, 562);
				g.drawString("C", 431, 562);
				g.drawString("K", 441, 562);
			}
			else {
				g.setFont(f2);
				g.drawString("X", 420, 569);
			}
			
			g.setFont(f2);
			g.drawString("<", 309, 569);
			g.drawString("___", 316, 552); // LEFT
			
			if(UpgradeKeeper.upgradePage == 0) {
				g.setColor(Color.ORANGE.darker().darker().darker());
				g.fillRect(145, 160, 175, 350);
				g.setColor(Color.ORANGE.darker());
				g.fillRect(165, 180, 135, 310);
				
				g.setColor(Color.ORANGE.darker().darker().darker());
				g.fillRect(345, 160, 175, 350);
				g.setColor(Color.ORANGE.darker());
				g.fillRect(365, 180, 135, 310);
				
				g.setColor(Color.ORANGE.darker().darker().darker());
				g.fillRect(545, 160, 175, 350);
				g.setColor(Color.ORANGE.darker());
				g.fillRect(565, 180, 135, 310);
				
				g.setColor(Color.BLACK);
				g.drawRect(145, 160, 175, 350);
				g.drawRect(345, 160, 175, 350);
				g.drawRect(545, 160, 175, 350);
				g.drawRect(165, 180, 135, 310);
				g.drawRect(365, 180, 135, 310);
				g.drawRect(565, 180, 135, 310);
				g.setColor(Color.WHITE);
				g.drawRect(144, 159, 175, 350);
				g.drawRect(344, 159, 175, 350);
				g.drawRect(544, 159, 175, 350);
				g.drawRect(164, 179, 135, 310);
				g.drawRect(364, 179, 135, 310);
				g.drawRect(564, 179, 135, 310);
				
				g.setFont(f5);
				g.setColor(Color.BLACK);
				g.drawString("Ingredients", 183, 225);
				g.drawString("Decorations", 380, 225);
				g.drawString("Gameplay", 588, 225);
				g.setColor(Color.WHITE);
				g.drawString("Ingredients", 182, 224);
				g.drawString("Decorations", 379, 224);
				g.drawString("Gameplay", 587, 224);
				
				g.drawImage(ingredientLogo, 181, 278, null);
				g.drawImage(decorationLogo, 383, 275, null); 
				g.drawImage(gameplayLogo, 583, 288, null);
			}
			if(UpgradeKeeper.upgradePage == 1) {
				if(UpgradeKeeper.uSauce == 3) {
					g.setColor(Color.ORANGE.darker().darker().darker().darker());
				}
				else {
					g.setColor(Color.ORANGE.darker().darker());
				}
				g.fillRect(150, 180, 155, 120); // 1
				
				if(UpgradeKeeper.uMozz == 3) {
					g.setColor(Color.ORANGE.darker().darker().darker().darker());
				}
				else {
					g.setColor(Color.ORANGE.darker().darker());
				}
				g.fillRect(358, 180, 155, 120); // 2
				
				if(UpgradeKeeper.uPepp == 3) {
					g.setColor(Color.ORANGE.darker().darker().darker().darker());
				}
				else {
					g.setColor(Color.ORANGE.darker().darker());
				}
				g.fillRect(566, 180, 155, 120); // 3
				
				g.setColor(Color.ORANGE.darker());
				g.fillRect(301, 330, 55, 30);
				g.fillRect(515, 330, 55, 30);
				
				g.setColor(Color.BLACK);
				g.drawRect(150, 180, 155, 120); // 1
				g.drawRect(358, 180, 155, 120); // 2
				g.drawRect(566, 180, 155, 120); // 3
				g.drawRect(301, 330, 55, 30);   // LEFT
				g.drawRect(515, 330, 55, 30);   // RIGHT
				g.setColor(Color.WHITE);
				g.drawRect(149, 179, 155, 120); // 1
				g.drawRect(357, 179, 155, 120); // 2
				g.drawRect(565, 179, 155, 120); // 3
				g.drawRect(300, 329, 55, 30);   // LEFT
				g.drawRect(514, 329, 55, 30);   // RIGHT
				
				g.setFont(f5);
				g.setColor(Color.BLACK);
				g.drawString("Page 1 of 3", 381, 351);
				g.drawString("Pizza", 203, 223);
				g.drawString("Sauce", 201, 241);
				g.drawString("$" + UpgradeKeeper.pSauce, 202, 275);
				g.drawString("Mozzarella", 389, 223);
				g.drawString("Cheese", 405, 241);
				g.drawString("$" + UpgradeKeeper.pMozz, 408, 275);
				g.drawString("Pepperoni", 601, 223);
				g.drawString("$" + UpgradeKeeper.pPepp, 618, 275);
				g.drawString("____", 522, 343); // RIGHT
				g.drawString("____", 309, 343); // LEFT
				g.drawString(">", 553, 352); 
				g.drawString("<", 307, 351);
				
				g.setColor(Color.WHITE);
				g.drawString("Page 1 of 3", 380, 350);
				g.drawString("Pizza", 202, 222);
				g.drawString("Sauce", 200, 240);
				g.drawString("Mozzarella", 388, 222);
				g.drawString("Cheese", 404, 240);
				g.drawString("Pepperoni", 600, 222);
				
				g.setColor(Color.ORANGE.darker().darker().darker().darker());
				if(UpgradeKeeper.uSauce == 3) {
					g.fillRect(163, 250, 130, 30);
				}
				if(UpgradeKeeper.uMozz == 3) {
					g.fillRect(373, 250, 130, 30);
				}
				if(UpgradeKeeper.uPepp == 3) {
					g.fillRect(578, 250, 130, 30);
				}
				
				g.setColor(Color.ORANGE.darker());
				g.fillRect(187, 395, 500, 100);
				g.setColor(Color.BLACK);
				g.drawRect(187, 395, 500, 100);
				g.setColor(Color.WHITE);
				g.drawRect(186, 394, 500, 100);
				
				g.setColor(Color.BLACK);
				if(hover1 == true && UpgradeKeeper.uSauce != 3) {
					g.setFont(f5);
					g.drawString("Pizza Sauce:  $" + UpgradeKeeper.pSauce, 205, 425);
					g.setFont(f6);
					g.drawString("Every pizza needs a good sauce, as it can make or break a pie.", 205, 451);
					g.drawString("Buying this upgrade will increase sauce profits.", 205, 468);
				}
				else if(hover1 == true && UpgradeKeeper.uSauce == 3) {
					g.setFont(f5);
					g.drawString("Pizza Sauce:", 205, 425);
					g.setFont(f6);
					g.drawString("This upgrade is at max level!", 205, 451);
				}
				if(hover2 == true && UpgradeKeeper.uMozz != 3) {
					g.setFont(f5);
					g.drawString("Mozzarella Cheese:  $" + UpgradeKeeper.pMozz, 205, 425);
					g.setFont(f6);
					g.drawString("The secret ingredient to a perfect pizza... the cheese.", 205, 451);
					g.drawString("Mozzarella is a classic, but it can always be better.", 205, 468);
				}
				else if(hover2 == true && UpgradeKeeper.uMozz == 3) {
					g.setFont(f5);
					g.drawString("Mozzarella Cheese:", 205, 425);
					g.setFont(f6);
					g.drawString("This upgrade is at max level!", 205, 451);
				}
				if(hover3 == true && UpgradeKeeper.uPepp != 3) {
					g.setFont(f5);
					g.drawString("Pepperoni:  $" + UpgradeKeeper.pPepp, 205, 425);
					g.setFont(f6);
					g.drawString("Delicious pepperoni slices are a classic topping on pizza pies.", 205, 451);
					g.drawString("Who doesn't love a pepperoni pizza?", 205, 468);
				}
				else if(hover3 == true && UpgradeKeeper.uPepp == 3) {
					g.setFont(f5);
					g.drawString("Pepperoni:", 205, 425);
					g.setFont(f6);
					g.drawString("This upgrade is at max level!", 205, 451);
				}
			}
			
			if(UpgradeKeeper.upgradePage == 2) {
				if(UpgradeKeeper.uChed == 2) {
					g.setColor(Color.ORANGE.darker().darker().darker().darker());
				}
				else {
					g.setColor(Color.ORANGE.darker().darker());
				}
				g.fillRect(150, 180, 155, 120); // 1
				
				if(UpgradeKeeper.uSaus == 2) {
					g.setColor(Color.ORANGE.darker().darker().darker().darker());
				}
				else {
					g.setColor(Color.ORANGE.darker().darker());
				}
				g.fillRect(358, 180, 155, 120); // 2
				
				if(UpgradeKeeper.uMush == 2) {
					g.setColor(Color.ORANGE.darker().darker().darker().darker());
				}
				else {
					g.setColor(Color.ORANGE.darker().darker());
				}
				g.fillRect(566, 180, 155, 120); // 3
				
				g.setColor(Color.ORANGE.darker());
				g.fillRect(301, 330, 55, 30);
				g.fillRect(515, 330, 55, 30);
				
				g.setColor(Color.BLACK);
				g.drawRect(150, 180, 155, 120); // 1
				g.drawRect(358, 180, 155, 120); // 2
				g.drawRect(566, 180, 155, 120); // 3
				g.drawRect(301, 330, 55, 30);   // LEFT
				g.drawRect(515, 330, 55, 30);   // RIGHT
				g.setColor(Color.WHITE);
				g.drawRect(149, 179, 155, 120); // 1
				g.drawRect(357, 179, 155, 120); // 2
				g.drawRect(565, 179, 155, 120); // 3
				g.drawRect(300, 329, 55, 30);   // LEFT
				g.drawRect(514, 329, 55, 30);   // RIGHT
				
				g.setFont(f5);
				g.setColor(Color.BLACK);
				g.drawString("Page 2 of 3", 381, 351);
				g.drawString("Cheddar", 193, 223);
				g.drawString("Cheese", 198, 241);
				g.drawString("$" + UpgradeKeeper.pChed, 202, 275);
				g.drawString("Sausage", 399, 223);
				g.drawString("$" + UpgradeKeeper.pSaus, 408, 275);
				g.drawString("Mushrooms", 593, 223);
				g.drawString("$" + UpgradeKeeper.pMush, 618, 275);
				g.drawString("____", 522, 343); // RIGHT
				g.drawString("____", 309, 343); // LEFT
				g.drawString(">", 553, 352); 
				g.drawString("<", 307, 351);
				
				g.setColor(Color.WHITE);
				g.drawString("Page 2 of 3", 380, 350);
				g.drawString("Cheddar", 192, 222);
				g.drawString("Cheese", 197, 240);
				g.drawString("Sausage", 398, 222);
				g.drawString("Mushrooms", 592, 222);
				
				g.setColor(Color.ORANGE.darker().darker().darker().darker());
				if(UpgradeKeeper.uChed == 2) {
					g.fillRect(163, 250, 130, 30);
				}
				if(UpgradeKeeper.uSaus == 2) {
					g.fillRect(373, 250, 130, 30);
				}
				if(UpgradeKeeper.uMush == 2) {
					g.fillRect(578, 250, 130, 30);
				}
				
				g.setColor(Color.ORANGE.darker());
				g.fillRect(187, 395, 500, 100);
				g.setColor(Color.BLACK);
				g.drawRect(187, 395, 500, 100);
				g.setColor(Color.WHITE);
				g.drawRect(186, 394, 500, 100);
				
				g.setColor(Color.BLACK);
				if(hover1 == true && UpgradeKeeper.uChed != 2) {
					g.setFont(f5);
					g.drawString("Cheddar Cheese:  $" + UpgradeKeeper.pChed, 205, 425);
					g.setFont(f6);
					g.drawString("Cheddar pies are for those with iron taste buds. Such rich flavor.", 205, 451);
					g.drawString("Having a second variety of cheese will really boost sales.", 205, 468);
				}
				else if(hover1 == true && UpgradeKeeper.uChed == 2) {
					g.setFont(f5);
					g.drawString("Cheddar Cheese:", 205, 425);
					g.setFont(f6);
					g.drawString("This upgrade is at max level!", 205, 451);
				}
				if(hover2 == true && UpgradeKeeper.uSaus != 2) {
					g.setFont(f5);
					g.drawString("Sausage:  $" + UpgradeKeeper.pSaus, 205, 425);
					g.setFont(f6);
					g.drawString("Sausage is a necessity for the meat lovers of the world.", 205, 451);
					g.drawString("These bad boys add an iconic burst of flavor to pizza pies.", 205, 468);
				}
				else if(hover2 == true && UpgradeKeeper.uSaus == 2) {
					g.setFont(f5);
					g.drawString("Sausage:", 205, 425);
					g.setFont(f6);
					g.drawString("This upgrade is at max level!", 205, 451);
				}
				if(hover3 == true && UpgradeKeeper.uMush != 2) {
					g.setFont(f5);
					g.drawString("Mushrooms:  $" + UpgradeKeeper.pMush, 205, 425);
					g.setFont(f6);
					g.drawString("Being both tasty and healthy, mushrooms make a great topping.", 205, 451);
					g.drawString("You don't have to feel guilty eating a mushroom pizza!", 205, 468);
				}
				else if(hover3 == true && UpgradeKeeper.uMush == 2) {
					g.setFont(f5);
					g.drawString("Mushrooms:", 205, 425);
					g.setFont(f6);
					g.drawString("This upgrade is at max level!", 205, 451);
				}
			}
			
			if(UpgradeKeeper.upgradePage == 3) {
				if(UpgradeKeeper.uOnion == 2) {
					g.setColor(Color.ORANGE.darker().darker().darker().darker());
				}
				else {
					g.setColor(Color.ORANGE.darker().darker());
				}
				g.fillRect(150, 180, 155, 120); // 1
				
				if(UpgradeKeeper.uOlive == 2) {
					g.setColor(Color.ORANGE.darker().darker().darker().darker());
				}
				else {
					g.setColor(Color.ORANGE.darker().darker());
				}
				g.fillRect(358, 180, 155, 120); // 2
				
				if(UpgradeKeeper.uSpin == 2) {
					g.setColor(Color.ORANGE.darker().darker().darker().darker());
				}
				else {
					g.setColor(Color.ORANGE.darker().darker());
				}
				g.fillRect(566, 180, 155, 120); // 3
				
				g.setColor(Color.ORANGE.darker());
				g.fillRect(301, 330, 55, 30);
				g.fillRect(515, 330, 55, 30);
				
				g.setColor(Color.BLACK);
				g.drawRect(150, 180, 155, 120); // 1
				g.drawRect(358, 180, 155, 120); // 2
				g.drawRect(566, 180, 155, 120); // 3
				g.drawRect(301, 330, 55, 30);   // LEFT
				g.drawRect(515, 330, 55, 30);   // RIGHT
				g.setColor(Color.WHITE);
				g.drawRect(149, 179, 155, 120); // 1
				g.drawRect(357, 179, 155, 120); // 2
				g.drawRect(565, 179, 155, 120); // 3
				g.drawRect(300, 329, 55, 30);   // LEFT
				g.drawRect(514, 329, 55, 30);   // RIGHT
				
				g.setFont(f5);
				g.setColor(Color.BLACK);
				g.drawString("Page 3 of 3", 381, 351);
				g.drawString("Onions", 197, 223);
				g.drawString("$" + UpgradeKeeper.pOnion, 202, 275);
				g.drawString("Olives", 409, 223);
				g.drawString("$" + UpgradeKeeper.pOlive, 408, 275);
				g.drawString("Spinach", 611, 223);
				g.drawString("$" + UpgradeKeeper.pSpin, 618, 275);
				g.drawString("____", 522, 343); // RIGHT
				g.drawString("____", 309, 343); // LEFT
				g.drawString(">", 553, 352); 
				g.drawString("<", 307, 351);
				
				g.setColor(Color.WHITE);
				g.drawString("Page 3 of 3", 380, 350);
				g.drawString("Onions", 196, 222);
				g.drawString("Olives", 408, 222);
				g.drawString("Spinach", 610, 222);
				
				g.setColor(Color.ORANGE.darker().darker().darker().darker());
				if(UpgradeKeeper.uOnion == 2) {
					g.fillRect(163, 250, 130, 30);
				}
				if(UpgradeKeeper.uOlive == 2) {
					g.fillRect(373, 250, 130, 30);
				}
				if(UpgradeKeeper.uSpin == 2) {
					g.fillRect(578, 250, 130, 30);
				}
				
				g.setColor(Color.ORANGE.darker());
				g.fillRect(187, 395, 500, 100);
				g.setColor(Color.BLACK);
				g.drawRect(187, 395, 500, 100);
				g.setColor(Color.WHITE);
				g.drawRect(186, 394, 500, 100);
				
				g.setColor(Color.BLACK);
				if(hover1 == true && UpgradeKeeper.uOnion != 2) {
					g.setFont(f5);
					g.drawString("Onions:  $" + UpgradeKeeper.pOnion, 205, 425);
					g.setFont(f6);
					g.drawString("If you enjoy toppings that give a small 'tang' to your pizza,", 205, 451);
					g.drawString("then onions are the perfect ingredient to add to your kitchen!", 205, 468);
				}
				else if(hover1 == true && UpgradeKeeper.uOnion == 2) {
					g.setFont(f5);
					g.drawString("Onions:", 205, 425);
					g.setFont(f6);
					g.drawString("This upgrade is at max level!", 205, 451);
				}
				if(hover2 == true && UpgradeKeeper.uOlive != 2) {
					g.setFont(f5);
					g.drawString("Olives:  $" + UpgradeKeeper.pOlive, 205, 425);
					g.setFont(f6);
					g.drawString("Black olives give off both a sweet and rich flavor; what a combo!", 205, 451);
					g.drawString("These tiny topping will make a big difference in your sales.", 205, 468);
				}
				else if(hover2 == true && UpgradeKeeper.uOlive == 2) {
					g.setFont(f5);
					g.drawString("Olives:", 205, 425);
					g.setFont(f6);
					g.drawString("This upgrade is at max level!", 205, 451);
				}
				if(hover3 == true && UpgradeKeeper.uSpin != 2) {
					g.setFont(f5);
					g.drawString("Spinach:  $" + UpgradeKeeper.pSpin, 205, 425);
					g.setFont(f6);
					g.drawString("This green leaf is huge in the flavor department.", 205, 451);
					g.drawString("It makes pizzas, both meat and veggie, taste wildly better.", 205, 468);
				}
				else if(hover3 == true && UpgradeKeeper.uSpin == 2) {
					g.setFont(f5);
					g.drawString("Spinach:", 205, 425);
					g.setFont(f6);
					g.drawString("This upgrade is at max level!", 205, 451);
				}
			}
			
			if(hover1 == true || hover2 == true || hover3 == true) {
				g.setColor(Color.ORANGE.darker().darker().darker());
				g.setFont(f4);
				g.fillRect(615, 402, 65, 86);
				g.setColor(Color.BLACK);
				g.drawRect(615, 402, 65, 86);
				g.drawString("B", 639, 430);
				g.drawString("U", 639, 455);
				g.drawString("Y", 640, 480);
				g.setColor(Color.WHITE);
				g.drawRect(614, 401, 65, 86);
				g.drawString("B", 637, 428);
				g.drawString("U", 637, 453);
				g.drawString("Y", 638, 478);
			}
			
			if(tooPoor == true) {
				g.setColor(Color.BLACK);
				g.setFont(f5);
				g.drawString("You don't have enough money to buy this upgrade!", 210, 450);
			}
			
			if(UpgradeKeeper.upgradePage == 4) {
				if(UpgradeKeeper.lampsBought == 1) {
					g.setColor(Color.ORANGE.darker().darker().darker().darker());
				}
				else {
					g.setColor(Color.ORANGE.darker().darker());
				}
				g.fillRect(150, 180, 155, 120); // 1
				
				if(UpgradeKeeper.poster1Bought == 1) {
					g.setColor(Color.ORANGE.darker().darker().darker().darker());
				}
				else {
					g.setColor(Color.ORANGE.darker().darker());
				}
				g.fillRect(358, 180, 155, 120); // 2
				
				if(UpgradeKeeper.wallpaperBought == 1) {
					g.setColor(Color.ORANGE.darker().darker().darker().darker());
				}
				else {
					g.setColor(Color.ORANGE.darker().darker());
				}
				g.fillRect(566, 180, 155, 120); // 3
				
				g.setColor(Color.ORANGE.darker());
				g.fillRect(301, 330, 55, 30);
				g.fillRect(515, 330, 55, 30);
				
				g.setColor(Color.BLACK);
				g.drawRect(150, 180, 155, 120); // 1
				g.drawRect(358, 180, 155, 120); // 2
				g.drawRect(566, 180, 155, 120); // 3
				g.drawRect(301, 330, 55, 30);   // LEFT
				g.drawRect(515, 330, 55, 30);   // RIGHT
				g.setColor(Color.WHITE);
				g.drawRect(149, 179, 155, 120); // 1
				g.drawRect(357, 179, 155, 120); // 2
				g.drawRect(565, 179, 155, 120); // 3
				g.drawRect(300, 329, 55, 30);   // LEFT
				g.drawRect(514, 329, 55, 30);   // RIGHT
				
				g.setFont(f5);
				g.setColor(Color.BLACK);
				g.drawString("Page 1 of 2", 381, 351);
				g.drawString("Lamps", 199, 223);
				g.drawString("$" + UpgradeKeeper.pLamps, 202, 275);
				g.drawString("Poster #1", 393, 223);
				g.drawString("$" + UpgradeKeeper.pPoster1, 408, 275);
				g.drawString("Wallpaper", 601, 223);
				g.drawString("$" + UpgradeKeeper.pWallpaper, 618, 275);
				g.drawString("____", 522, 343); // RIGHT
				g.drawString("____", 309, 343); // LEFT
				g.drawString(">", 553, 352); 
				g.drawString("<", 307, 351);
				
				g.setColor(Color.WHITE);
				g.drawString("Page 1 of 2", 380, 350);
				g.drawString("Lamps", 198, 222);
				g.drawString("Poster #1", 392, 222);
				g.drawString("Wallpaper", 600, 222);
				
				g.setColor(Color.ORANGE.darker().darker().darker().darker());
				if(UpgradeKeeper.lampsBought == 1) {
					g.fillRect(163, 250, 130, 30);
				}
				if(UpgradeKeeper.poster1Bought == 1) {
					g.fillRect(373, 250, 130, 30);
				}
				if(UpgradeKeeper.wallpaperBought == 1) {
					g.fillRect(578, 250, 130, 30);
				}
				
				g.setColor(Color.ORANGE.darker());
				g.fillRect(187, 395, 500, 100);
				g.setColor(Color.BLACK);
				g.drawRect(187, 395, 500, 100);
				g.setColor(Color.WHITE);
				g.drawRect(186, 394, 500, 100);
				
				g.setColor(Color.BLACK);
				if(hover1 == true && UpgradeKeeper.lampsBought == 0) {
					g.setFont(f5);
					g.drawString("Lamps:  $" + UpgradeKeeper.pLamps, 205, 425);
					g.setFont(f6);
					g.drawString("It is a known fact that Thomas Edison invented the light bulb so", 205, 451);
					g.drawString("that he could eat his favorite pizza and look at it at the same time.", 205, 468);
				}
				else if(hover1 == true && UpgradeKeeper.lampsBought == 1) {
					g.setFont(f5);
					g.drawString("Lamps:", 205, 425);
					g.setFont(f6);
					g.drawString("This upgrade has already been bought!", 205, 451);
				}
				if(hover2 == true && UpgradeKeeper.poster1Bought == 0) {
					g.setFont(f5);
					g.drawString("Poster #1:  $" + UpgradeKeeper.pPoster1, 205, 425);
					g.setFont(f6);
					g.drawString("Advertisement posters will help promote your delicious pizza pies", 205, 451);
					g.drawString("to the masses. It'll also help fill those empty walls in your store!", 205, 468);
				}
				else if(hover2 == true && UpgradeKeeper.poster1Bought == 1) {
					g.setFont(f5);
					g.drawString("Poster #1:", 205, 425);
					g.setFont(f6);
					g.drawString("This upgrade has already been bought!", 205, 451);
				}
				if(hover3 == true && UpgradeKeeper.wallpaperBought == 0) {
					g.setFont(f5);
					g.drawString("Wallpaper:  $" + UpgradeKeeper.pWallpaper, 205, 425);
					g.setFont(f6);
					g.drawString("Are you getting tired of looking at those boring orange walls?", 205, 451);
					g.drawString("This upgrade will cover those walls with a slightly better design.", 205, 468);
				}
				else if(hover3 == true && UpgradeKeeper.wallpaperBought == 1) {
					g.setFont(f5);
					g.drawString("Wallpaper:", 205, 425);
					g.setFont(f6);
					g.drawString("This upgrade has already been bought!", 205, 451);
				}
			}
			if(UpgradeKeeper.upgradePage == 5) {
				if(UpgradeKeeper.doorbellBought == 1) {
					g.setColor(Color.ORANGE.darker().darker().darker().darker());
				}
				else {
					g.setColor(Color.ORANGE.darker().darker());
				}
				g.fillRect(150, 180, 155, 120); // 1
				
				if(UpgradeKeeper.poster2Bought == 1) {
					g.setColor(Color.ORANGE.darker().darker().darker().darker());
				}
				else {
					g.setColor(Color.ORANGE.darker().darker());
				}
				g.fillRect(358, 180, 155, 120); // 2
				
				if(UpgradeKeeper.plantsBought == 1) {
					g.setColor(Color.ORANGE.darker().darker().darker().darker());
				}
				else {
					g.setColor(Color.ORANGE.darker().darker());
				}
				g.fillRect(566, 180, 155, 120); // 3
				
				g.setColor(Color.ORANGE.darker());
				g.fillRect(301, 330, 55, 30);
				g.fillRect(515, 330, 55, 30);
				
				g.setColor(Color.BLACK);
				g.drawRect(150, 180, 155, 120); // 1
				g.drawRect(358, 180, 155, 120); // 2
				g.drawRect(566, 180, 155, 120); // 3
				g.drawRect(301, 330, 55, 30);   // LEFT
				g.drawRect(515, 330, 55, 30);   // RIGHT
				g.setColor(Color.WHITE);
				g.drawRect(149, 179, 155, 120); // 1
				g.drawRect(357, 179, 155, 120); // 2
				g.drawRect(565, 179, 155, 120); // 3
				g.drawRect(300, 329, 55, 30);   // LEFT
				g.drawRect(514, 329, 55, 30);   // RIGHT
				
				g.setFont(f5);
				g.setColor(Color.BLACK);
				g.drawString("Page 2 of 2", 381, 351);
				g.drawString("Doorbell", 191, 223);
				g.drawString("$" + UpgradeKeeper.pDoorbell, 202, 275);
				g.drawString("Poster #2", 393, 223);
				g.drawString("$" + UpgradeKeeper.pPoster2, 408, 275);
				g.drawString("Plants", 617, 223);
				g.drawString("$" + UpgradeKeeper.pPlants, 618, 275);
				g.drawString("____", 522, 343); // RIGHT
				g.drawString("____", 309, 343); // LEFT
				g.drawString(">", 553, 352); 
				g.drawString("<", 307, 351);
				
				g.setColor(Color.WHITE);
				g.drawString("Page 2 of 2", 380, 350);
				g.drawString("Doorbell", 190, 222);
				g.drawString("Poster #2", 392, 222);
				g.drawString("Plants", 616, 222);
				
				g.setColor(Color.ORANGE.darker().darker().darker().darker());
				if(UpgradeKeeper.doorbellBought == 1) {
					g.fillRect(163, 250, 130, 30);
				}
				if(UpgradeKeeper.poster2Bought == 1) {
					g.fillRect(373, 250, 130, 30);
				}
				if(UpgradeKeeper.plantsBought == 1) {
					g.fillRect(578, 250, 130, 30);
				}
				
				g.setColor(Color.ORANGE.darker());
				g.fillRect(187, 395, 500, 100);
				g.setColor(Color.BLACK);
				g.drawRect(187, 395, 500, 100);
				g.setColor(Color.WHITE);
				g.drawRect(186, 394, 500, 100);
				
				g.setColor(Color.BLACK);
				if(hover1 == true && UpgradeKeeper.doorbellBought == 0) {
					g.setFont(f5);
					g.drawString("Doorbell:  $" + UpgradeKeeper.pDoorbell, 205, 425);
					g.setFont(f6);
					g.drawString("The installation of a doorbell will help remind you that you have", 205, 451);
					g.drawString("more work to do! Warning... if you hate bells then don't buy this.", 205, 468);
				}
				else if(hover1 == true && UpgradeKeeper.doorbellBought == 1) {
					g.setFont(f5);
					g.drawString("Doorbell:", 205, 425);
					g.setFont(f6);
					g.drawString("This upgrade has already been bought!", 205, 451);
				}
				if(hover2 == true && UpgradeKeeper.poster2Bought == 0) {
					g.setFont(f5);
					g.drawString("Poster #2:  $" + UpgradeKeeper.pPoster1, 205, 425);
					g.setFont(f6);
					g.drawString("Another beautiful poster to cover up those ugly, bare walls.", 205, 451);
					g.drawString("Hopefully it'll make your customers hungry for fresh pizza pies.", 205, 468);
				}
				else if(hover2 == true && UpgradeKeeper.poster2Bought == 1) {
					g.setFont(f5);
					g.drawString("Poster #2:", 205, 425);
					g.setFont(f6);
					g.drawString("This upgrade has already been bought!", 205, 451);
				}
				if(hover3 == true && UpgradeKeeper.plantsBought == 0) {
					g.setFont(f5);
					g.drawString("Plants:  $" + UpgradeKeeper.pPlants, 205, 425);
					g.setFont(f6);
					g.drawString("Fresh potted plants will give your store some variety in", 205, 451);
					g.drawString("decoration, as well as give your store a more 'fresh' feeling.", 205, 468);
				}
				else if(hover3 == true && UpgradeKeeper.plantsBought == 1) {
					g.setFont(f5);
					g.drawString("Plants:", 205, 425);
					g.setFont(f6);
					g.drawString("This upgrade has already been bought!", 205, 451);
				}
			}
			if(UpgradeKeeper.upgradePage == 6) {
				if(UpgradeKeeper.gDayTime == 2) {
					g.setColor(Color.ORANGE.darker().darker().darker().darker());
				}
				else {
					g.setColor(Color.ORANGE.darker().darker());
				}
				g.fillRect(150, 180, 155, 120); // 1
				
				if(UpgradeKeeper.gCookTime == 2) {
					g.setColor(Color.ORANGE.darker().darker().darker().darker());
				}
				else {
					g.setColor(Color.ORANGE.darker().darker());
				}
				g.fillRect(358, 180, 155, 120); // 2
				
				if(UpgradeKeeper.gMoneyMul == 2) {
					g.setColor(Color.ORANGE.darker().darker().darker().darker());
				}
				else {
					g.setColor(Color.ORANGE.darker().darker());
				}
				g.fillRect(566, 180, 155, 120); // 3
				
				g.setColor(Color.BLACK);
				g.drawRect(150, 180, 155, 120); // 1
				g.drawRect(358, 180, 155, 120); // 2
				g.drawRect(566, 180, 155, 120); // 3
				g.setColor(Color.WHITE);
				g.drawRect(149, 179, 155, 120); // 1
				g.drawRect(357, 179, 155, 120); // 2
				g.drawRect(565, 179, 155, 120); // 3
				
				g.setFont(f5);
				g.setColor(Color.BLACK);
				g.drawString("Day Time", 187, 223);
				g.drawString("$" + UpgradeKeeper.pDaytime, 202, 275);
				g.drawString("Cook Time", 390, 223);
				g.drawString("$" + UpgradeKeeper.pCookTime, 408, 275);
				g.drawString("Money", 617, 223);
				g.drawString("Multiplier", 606, 241);
				g.drawString("$" + UpgradeKeeper.pMoneyMul, 612, 275);
				
				g.setColor(Color.WHITE);
				g.drawString("Day Time", 186, 222);
				g.drawString("Cook Time", 389, 222);
				g.drawString("Money", 616, 222);
				g.drawString("Multiplier", 605, 240);
				
				g.setColor(Color.ORANGE.darker().darker().darker().darker());
				if(UpgradeKeeper.gDayTime == 2) {
					g.fillRect(163, 250, 130, 30);
				}
				if(UpgradeKeeper.gCookTime == 2) {
					g.fillRect(373, 250, 130, 30);
				}
				if(UpgradeKeeper.gMoneyMul == 2) {
					g.fillRect(578, 250, 130, 30);
				}
				
				g.setColor(Color.ORANGE.darker());
				g.fillRect(187, 395, 500, 100);
				g.setColor(Color.BLACK);
				g.drawRect(187, 395, 500, 100);
				g.setColor(Color.WHITE);
				g.drawRect(186, 394, 500, 100);
				
				g.setColor(Color.BLACK);
				if(hover1 == true && UpgradeKeeper.gDayTime < 2) {
					g.setFont(f5);
					g.drawString("Day Time:  $" + UpgradeKeeper.pDaytime, 205, 425);
					g.setFont(f6);
					g.drawString("This upgrade will increase how long in-game days are,", 205, 451);
					g.drawString("which will give you more time to serve more customers!", 205, 468);
				}
				else if(hover1 == true && UpgradeKeeper.gDayTime == 2) {
					g.setFont(f5);
					g.drawString("Day Time:", 205, 425);
					g.setFont(f6);
					g.drawString("This upgrade is at max level!", 205, 451);
				}
				if(hover2 == true && UpgradeKeeper.gCookTime < 2) {
					g.setFont(f5);
					g.drawString("Cook Time:  $" + UpgradeKeeper.pCookTime, 205, 425);
					g.setFont(f6);
					g.drawString("Your oven is standing on it's last legs, it's time for an upgrade.", 205, 451);
					g.drawString("This upgrade will increase the efficiency and speed of your oven.", 205, 468);
				}
				else if(hover2 == true && UpgradeKeeper.gCookTime == 2) {
					g.setFont(f5);
					g.drawString("Cook Time:", 205, 425);
					g.setFont(f6);
					g.drawString("This upgrade is at max level!", 205, 451);
				}
				if(hover3 == true && UpgradeKeeper.gMoneyMul < 2) {
					g.setFont(f5);
					g.drawString("Money Multiplier:  $" + UpgradeKeeper.pMoneyMul, 205, 425);
					g.setFont(f6);
					g.drawString("The magnum opus of upgrades. This is the best item in the game.", 205, 451);
					g.drawString("Owning this upgrade will double/triple all of your profits.", 205, 468);
				}
				else if(hover3 == true && UpgradeKeeper.gMoneyMul == 2) {
					g.setFont(f5);
					g.drawString("Money Multiplier:", 205, 425);
					g.setFont(f6);
					g.drawString("This upgrade is at max level!", 205, 451);
				}
			}
			
			if(hover1 == true || hover2 == true || hover3 == true) {
				g.setColor(Color.ORANGE.darker().darker().darker());
				g.setFont(f4);
				g.fillRect(615, 402, 65, 86);
				g.setColor(Color.BLACK);
				g.drawRect(615, 402, 65, 86);
				g.drawString("B", 639, 430);
				g.drawString("U", 639, 455);
				g.drawString("Y", 640, 480);
				g.setColor(Color.WHITE);
				g.drawRect(614, 401, 65, 86);
				g.drawString("B", 637, 428);
				g.drawString("U", 637, 453);
				g.drawString("Y", 638, 478);
			}
			
			if(tooPoor == true) {
				g.setColor(Color.BLACK);
				g.setFont(f5);
				g.drawString("You don't have enough money to buy this upgrade!", 210, 450);
			}
			
			g.setFont(f3);
			g.setColor(Color.BLACK);
			g.drawString("� Vicious Games, Reid Cruzan, 2021-22", 332, 635);
		}
		
		
		
		else if(Game.gameState == Game.STATE.Confirm) {
			Font f  = new Font("Haettenschweiler", Font.PLAIN, 90);
			Font f2 = new Font("Franklin Gothic Medium", Font.PLAIN, 40);
			Font f3 = new Font("Franklin Gothic Medium", Font.PLAIN, 12);
			Font f4 = new Font("Franklin Gothic Medium", Font.BOLD, 24);
			Font f5 = new Font("Franklin Gothic Medium", Font.BOLD, 18);
			
			g.setFont(f);
			g.setColor(Color.BLACK);
			g.drawString("CONFIRM", 317, 130);
			g.setColor(Color.WHITE);
			g.drawString("CONFIRM", 312, 125);
			
			g.setColor(Color.ORANGE.darker());
			g.fillRect(310, 440, 240, 64);

			g.setColor(Color.BLACK);
			g.drawRect(406, 531, 50, 50); // X BUTTON
			g.drawRect(311, 441, 240, 64);
	
			g.setFont(f2);
			g.drawString("Yes", 402, 488);
			g.setFont(f5);
			g.drawString("B", 409, 563);
			g.drawString("A", 420, 563);
			g.drawString("C", 432, 563);
			g.drawString("K", 442, 563);
			
			g.setColor(Color.WHITE);
			g.drawRect(405, 530, 50, 50); // X BUTTON
			g.drawRect(310, 440, 240, 64);
			
			g.setFont(f2);
			g.drawString("Yes", 400, 486);
			g.setFont(f5);
			g.drawString("B", 408, 562);
			g.drawString("A", 419, 562);
			g.drawString("C", 431, 562);
			g.drawString("K", 441, 562);
			
			g.setFont(f4);
			g.setColor(Color.BLACK);
			g.drawString("Do you want to continue to", 285, 230);
			g.drawString("the next day?", 360, 265);
			
			g.setFont(f3);
			g.setColor(Color.BLACK);
			g.drawString("� Vicious Games, Reid Cruzan, 2021-22", 332, 635);
		}
		
		else if(Game.gameState == Game.STATE.End) {
			Font f  = new Font("Haettenschweiler", Font.PLAIN, 160);
			Font f2 = new Font("Franklin Gothic Medium", Font.PLAIN, 40);
			Font f3 = new Font("Franklin Gothic Medium", Font.PLAIN, 12);
			Font f4 = new Font("Franklin Gothic Medium", Font.BOLD, 18);
			
			g.setFont(f);
			g.setColor(Color.BLACK);
			g.drawString("THE END", 255, 145);
			g.setColor(Color.WHITE);
			g.drawString("THE END", 250, 140);
			
			g.setFont(f2);
			g.setColor(Color.BLACK);
			g.drawString("Congratulations!", 297, 222);
			g.setColor(Color.WHITE);
			g.drawString("Congratulations!", 295, 220);
			
			g.setFont(f4);
			g.setColor(Color.BLACK);
			g.drawString("You successfully ran the pizza store without running it into the ground!", 140, 280);
			g.drawString("The patience that you wield is truly amazing. This couldn't have been easy.", 125, 310);
			g.drawString("Constant work and no play, and for little in return as well. That's life.", 150, 340);
			g.drawString("I bet that you are really happy with yourself reading this!", 190, 370);
			
			g.drawString("Seriously though, thank you for playing.", 267, 430);
			g.drawString("I hope that you come back and play my next game.", 223, 460);
			
			g.setFont(f2);
			g.setColor(Color.BLACK);
			g.drawRect((int) (Game.WIDTH / 3) + 15, 510, 240, 64);
			g.drawString("Quit", 396, 555);
			g.setColor(Color.WHITE);
			g.drawRect((int) (Game.WIDTH / 3) + 14, 509, 240, 64);
			g.drawString("Quit", 394, 553);
			
			g.setFont(f3);
			g.setColor(Color.BLACK);
			g.drawString("� Vicious Games, Reid Cruzan, 2021-22", 332, 635);
		}
		
		// MUTE BUTTON
		int[] xP = {12, 42, 42}; int[] xP2 = {10, 40, 40};
		int[] yP = {37, 19, 55}; int[] yP2 = {34, 16, 52};
		
		g.setColor(Color.BLACK);
		g.drawRoundRect(4, 6, 58, 58, 15, 15);
		g.fillRect(13, 29, 22, 16);
		g.fillPolygon(xP, yP, 3);
		
		g.setColor(Color.WHITE);
		g.drawRoundRect(3, 5, 58, 58, 15, 15);
		g.fillRect(11, 27, 22, 16);
		g.fillPolygon(xP2, yP2, 3);
		
		if(!Game.muted) {
			g.setColor(Color.BLACK);
			g.drawArc(17, 20, 30, 30, -25, 50);
			g.drawArc(16, 10, 35, 50, -25, 50);
			g.drawArc(16, 0, 40, 70, -25, 50);
			
			g.setColor(Color.WHITE);
			g.drawArc(15, 19, 30, 30, -25, 50);
			g.drawArc(14, 9, 35, 50, -25, 50);
			g.drawArc(14, -1, 40, 70, -25, 50);
		}
		
		
		int[] xP3 = {846, 846, 878}; int[] xP4 = {845, 845, 877};
		int[] yP3 = {17, 53, 35}; int[] yP4 = {15, 51, 33};
		
		if(Game.gameState == Game.STATE.Game && GameDisplay.displayState == GameDisplay.STATE.Gameplay) {
			
			// PAUSE BUTTON
			g.setColor(Color.BLACK);
			g.drawRoundRect(832, 6, 58, 58, 15, 15);
			g.setColor(Color.WHITE);
			g.drawRoundRect(831, 5, 58, 58, 15, 15);
			
			if(!Game.paused) {
				g.setColor(Color.BLACK);
				g.fillRect(847, 18, 10, 35);
				g.fillRect(866, 18, 10, 35);
				g.setColor(Color.WHITE);
				g.fillRect(845, 16, 10, 35);
				g.fillRect(864, 16, 10, 35);
			}
			else {
				g.setColor(Color.BLACK);
				g.fillPolygon(xP3, yP3, 3);
				g.setColor(Color.WHITE);
				g.fillPolygon(xP4, yP4, 3);
				
				Font f = new Font("Arial", Font.BOLD, 20);
				g.setFont(f);
				g.setColor(Color.RED.darker().darker());
				g.drawString("PAUSED", 391, 74);
				g.setColor(Color.RED);
				g.drawString("PAUSED", 390, 73);
			}
			
			// TRASH BUTTON
				g.setColor(Color.BLACK);
				g.drawRoundRect(832, 582, 58, 58, 15, 15);
				g.fillRect(843, 599, 37, 6);
				g.fillRect(846, 600, 31, 33);
				g.fillRect(851, 593, 5, 6);
				g.fillRect(867, 593, 5, 6);
				g.fillRect(851, 592, 21, 4);
				
				g.setColor(Color.RED.brighter().brighter());
				g.drawRoundRect(831, 581, 58, 58, 15, 15);
				g.fillRect(841, 597, 37, 6);
				g.fillRect(844, 598, 31, 33);
				g.fillRect(849, 591, 5, 6);
				g.fillRect(865, 591, 5, 6);
				g.fillRect(849, 590, 21, 4);
				
				g.setColor(Color.BLACK);
				g.fillRect(850, 604, 2, 22);
				g.fillRect(859, 604, 2, 22);
				g.fillRect(868, 604, 2, 22);
		}
		
		// SCORE METER
		if(scoreShowing == true && HUD.TIME > 0) {
			Font f = new Font("Arial", Font.PLAIN, 44);
			g.setFont(f);
			g.setColor(Color.BLACK);
			g.drawString(score + " / 100", 160, 202);
			g.setColor(Color.WHITE);
			g.drawString(score + " / 100", 158, 200);
		}
	}
}
