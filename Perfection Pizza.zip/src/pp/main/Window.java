package pp.main;
import java.awt.Canvas;
import java.awt.Dimension;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

import pp.Game;

public class Window extends Canvas {

	private static final long serialVersionUID = 23169830502634099L;
	private boolean hasRun = false;
	
	public Window(int width, int height, String title, Game game) {
		if(!hasRun) {
		JFrame frame = new JFrame(title);
		frame.setPreferredSize(new Dimension(width, height));
		frame.setMaximumSize(new Dimension(width, height));
		frame.setMinimumSize(new Dimension(width, height));
		
		ImageIcon img = new ImageIcon("res/images/pizza.png");
		frame.setIconImage(img.getImage());
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);

		frame.setVisible(true);
		frame.add(game);
		
		hasRun = true;
		game.start();
		}
	}
}
