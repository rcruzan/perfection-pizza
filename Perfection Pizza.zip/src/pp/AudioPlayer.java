package pp;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.newdawn.slick.Music;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Sound;

public class AudioPlayer {

	public static Map<String, Sound> soundMap = new HashMap<String, Sound>();
	public static Map<String, Music> musicMap = new HashMap<String, Music>();
	
	public static URL click, 
	   				  ovenHum, 
	   				  ovenDing, 
	   				  purchase, 
	   				  bell, 
	   				  trash;
    public static URL main, 
	   				  epic, 
	   				  end;
	
	public static void load() {
		
		try {
			soundMap.put("click", new Sound(click));
			soundMap.put("ovenHum", new Sound(ovenHum));
			soundMap.put("ovenDing", new Sound(ovenDing));
			soundMap.put("purchase", new Sound(purchase));
			soundMap.put("bell", new Sound(bell));
			soundMap.put("trash", new Sound(trash));
			
			musicMap.put("mainMusic", new Music(main));	
			musicMap.put("epicMusic", new Music(epic));	
			musicMap.put("endMusic", new Music(end));	
			
		} catch (SlickException e) {
			e.printStackTrace();
		}	
	}
	
	public static Music getMusic(String key) {
		return musicMap.get(key);
	}
	
	public static Sound getSound(String key) {
		return soundMap.get(key);
	}
}
