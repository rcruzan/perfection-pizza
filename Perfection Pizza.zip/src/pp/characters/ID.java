package pp.characters;

public enum ID {
	MenuParticle(),
	Customer(),
}
