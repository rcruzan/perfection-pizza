package pp.particles;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import pp.Game;
import pp.GameObject;
import pp.characters.ID;
import pp.main.Handler;

public class MenuParticle extends GameObject {

	Handler handler;
	Color c;
	
	public MenuParticle(int x, int y, ID id, Handler handler, Color c) {
		super(x, y, id, handler);
		
		this.c = c;
		speedY = 1.5f;
	}
	
	public Rectangle getBounds() {
		return new Rectangle((int) x, (int) y, 16, 16);
	}

	public void tick() {
		y += speedY;
	
		if(y <= -4 || y >= Game.HEIGHT - 68) speedY *= -1;
	}

	public void render(Graphics g) {
		g.setColor(c);
		g.fillRect((int) x, (int) y, (Game.HEIGHT/20) - 1, (Game.HEIGHT/20));
	}
}
