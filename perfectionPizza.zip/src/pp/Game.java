package pp;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;

import pp.characters.ID;
import pp.characters.Spawn;
import pp.main.GameDisplay;
import pp.main.HUD;
import pp.main.Handler;
import pp.main.Menu;
import pp.main.StatKeeper;
import pp.main.Window;
import pp.particles.MenuParticle;

public class Game extends Canvas implements Runnable {

	public static boolean muted = false;
	public static boolean paused = false;
	public static final int WIDTH = 910;
	public static final int HEIGHT = (WIDTH / 12 * 9) + 8;
	private static final long serialVersionUID = 7778060330323149216L;
	
	private HUD hud;
	private Menu menu;
	private Spawn spawn;
	private Thread thread;
	private Handler handler;
	private GameDisplay gameDisplay;
	@SuppressWarnings("unused")
	private AudioPlayer ap;
	boolean running = false;

	public enum STATE {
		Main,
		Help,
		Credits,

		Game,
		Menu,
		Stats,
		Upgrade,
		Confirm,
		
		End
	};
	
	public static STATE gameState = STATE.Main;
	
	public Game() {
		hud = new HUD();
		handler = new Handler();
		menu = new Menu(this, handler, hud);
		gameDisplay = new GameDisplay(this, handler, hud);
		this.addMouseListener(menu);
		
		AudioPlayer.click = getClass().getClassLoader().getResource("music/click.ogg");
		AudioPlayer.ovenHum = getClass().getClassLoader().getResource("music/ovenHum.ogg");
		AudioPlayer.ovenDing = getClass().getClassLoader().getResource("music/ovenDing.ogg");
		AudioPlayer.purchase = getClass().getClassLoader().getResource("music/purchase.ogg");
		AudioPlayer.bell = getClass().getClassLoader().getResource("music/storeBell.ogg");
		AudioPlayer.trash = getClass().getClassLoader().getResource("music/trash.ogg");
		
		AudioPlayer.main = getClass().getClassLoader().getResource("music/mainMusic.ogg");
		AudioPlayer.epic = getClass().getClassLoader().getResource("music/epicMusic.ogg");
		AudioPlayer.end = getClass().getClassLoader().getResource("music/endMusic.ogg");
		
		AudioPlayer.load();
		AudioPlayer.getMusic("mainMusic").loop(1, 0.1f);
		
		if(gameState == STATE.Main) {
			// MOVING TILES
			new MenuParticle(0, 0, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(33, 33, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(0, 66, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(33, 99, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(0, 132, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(33, 165, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(0, 198, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(33, 231, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(0, 264, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(33, 297, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(0, 330, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(33, 363, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(0, 396, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(33, 429, ID.MenuParticle, handler, Color.BLACK);
			
			new MenuParticle(861, 0, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(828, 33, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(861, 66, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(828, 99, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(861, 132, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(828, 165, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(861, 198, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(828, 231, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(861, 264, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(828, 297, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(861, 330, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(828, 363, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(861, 396, ID.MenuParticle, handler, Color.BLACK);
			new MenuParticle(828, 429, ID.MenuParticle, handler, Color.BLACK);		
		}
		
		new Window(WIDTH, HEIGHT, "PERFECTION PIZZA", this);
		spawn = new Spawn(this, handler, hud);
	}
	
	public synchronized void start() {
		thread = new Thread(this);
		thread.start();
		running = true;
	}
	
	public synchronized void stop() {
		try {
			thread.join();
			running = false;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void run() {
		
		int frames = 0;
		double delta = 0;
		double tickCount = 60.0;
		long lastTime = System.nanoTime();
		long timer = System.currentTimeMillis();
		double nanoSeconds = 1000000000 / tickCount;
		this.requestFocus();
		
		while(running) {
			long now = System.nanoTime();
			delta += (now - lastTime) / nanoSeconds;
			lastTime = now;
			
		while(delta >= 1) {
			tick();
			delta--;
			}
			
		if(running) 
			render();
			frames++;
			
		if(System.currentTimeMillis() - timer > 1000) {
			timer += 1000;
			System.out.println("FPS: " + frames);
			frames = 0;
				}
			}
		stop();
	}
	
	private void tick() {
		
		if(gameState == STATE.Game && GameDisplay.displayState == GameDisplay.STATE.Gameplay) {
			if(!paused) {
			handler.tick();
			gameDisplay.tick();
			hud.tick();
			menu.tick();
			spawn.tick();
				
			if(HUD.TIME <= 0) {
		  	HUD.TIME = 100;
		  	hud.setDay(HUD.getDay() + 1);
		  	Menu.scoreShowing = false;
		  	
		  	GameDisplay.dough = 0;
			GameDisplay.sauce = 0;
			GameDisplay.mozz = 0;
			GameDisplay.ched = 0;
			GameDisplay.pepp = 0;
			GameDisplay.saus = 0;
			GameDisplay.mush = 0;
			GameDisplay.onion = 0;
			GameDisplay.olives = 0;
			GameDisplay.spin = 0;
			GameDisplay.isCooked = 0;
			GameDisplay.isCut = 0;
			
			Spawn.daveSpawn = 0;
			Spawn.billSpawn = 0;
			Spawn.clintSpawn = 0;
			Spawn.annaSpawn = 0;
			Spawn.paulaSpawn = 0;
			Spawn.jacksonSpawn = 0;
			Spawn.sherylSpawn = 0;
			Spawn.charlieSpawn = 0;
			Spawn.maxwellSpawn = 0;
			Spawn.brucieSpawn = 0;
			handler.clearCustomers();
		  	
		  	Spawn.timeKeep = 0;
		  	GameDisplay.timer = 0;
		  	StatKeeper.profitSet(HUD.money, HUD.day);
		  	GameDisplay.displayState = GameDisplay.STATE.DayOver;	
			}
		}
	}
		else if(gameState == STATE.Game && GameDisplay.displayState == GameDisplay.STATE.DayCounter) {
			gameDisplay.tick();
			menu.tick();
		}
		
		else if(gameState == STATE.Game && GameDisplay.displayState == GameDisplay.STATE.DayOver) {
			gameDisplay.tick();
			menu.tick();
		}
		
		else if(gameState == STATE.Main || Game.gameState == Game.STATE.Confirm ||gameState == STATE.Help || gameState == STATE.Credits || gameState == STATE.Menu 
				 || gameState == STATE.Stats || gameState == STATE.Upgrade || gameState == STATE.End) {
			menu.tick();
			handler.tick();
		}
	}
	
	private void render() {
		
		BufferStrategy bs = this.getBufferStrategy();
		if(bs == null) {
			this.createBufferStrategy(3);
			return;
		}
		
		Graphics g = bs.getDrawGraphics();
		g.setColor(Color.ORANGE);
		g.fillRect(0, 0, WIDTH, HEIGHT);
		
		g.setColor(Color.ORANGE.darker());
		g.fillRect(0, 0, 66, 700);
		g.fillRect(828, 0, 66, 700);
		
		handler.render(g);
		
		if(gameState == STATE.Game && GameDisplay.displayState == GameDisplay.STATE.DayCounter) {
			gameDisplay.render(g);
			menu.render(g);
		}
		
		else if(gameState == STATE.Game && GameDisplay.displayState == GameDisplay.STATE.Gameplay) {
			gameDisplay.render(g);
			menu.render(g);
			hud.render(g);
			handler.render(g);
		}
		
		else if(gameState == STATE.Game && GameDisplay.displayState == GameDisplay.STATE.DayOver) {
			gameDisplay.render(g);
			menu.render(g);
		}
		
		else if(gameState == STATE.Main || Game.gameState == Game.STATE.Confirm || gameState == STATE.Help || gameState == STATE.Credits || gameState == STATE.Menu 
		     || gameState == STATE.Stats || gameState == STATE.Upgrade || gameState == STATE.End) {
			menu.render(g);	
		}
		
		g.dispose();
		bs.show();
	}
	
	public static float clamp(float var, float min, float max) {
		if(var >= max) {
			return var = max;
		}
		else if(var <= min) {
			return var = min;
		}
		else {
			return var;
		}
	}
	
	public static void main(String[] args) {
		new Game();
	}
}
