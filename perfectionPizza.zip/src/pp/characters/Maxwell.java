package pp.characters;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;

import pp.GameObject;
import pp.main.GameDisplay;
import pp.main.Handler;
import pp.main.UpgradeKeeper;

public class Maxwell extends GameObject {

	static Toolkit k = Toolkit.getDefaultToolkit();
	Image speechBubble = k.getImage(getClass().getClassLoader().getResource("images/characters/bubble.png"));
//	Image bill = k.getImage(getClass().getClassLoader().getResource("characters/bill.png"));
	
	// 0 = DISLIKE, 1 = LIKE
	public static int mozzPref = 1,
					  chedPref = 0,
					  peppPref = 1,
					  sausPref = 0,
					  mushPref = 0,
					 onionPref = 0,
					 olivePref = 0,
					  spinPref = 0,
					  isCooked = 1,
					     isCut = 1;
	
	public Maxwell(int x, int y, ID id, Handler handler) {
		super(x, y, id, handler);
		
		if(UpgradeKeeper.uChed != 0) {
			mozzPref = 0;
			chedPref = 1;
		}
		if(UpgradeKeeper.uSaus != 0) {
			sausPref = 1;
		}
		if(UpgradeKeeper.uMush != 0) {
			mushPref = 1;
		}
		if(UpgradeKeeper.uOnion != 0) {
			onionPref = 1;
		}
		if(UpgradeKeeper.uOlive != 0) {
			olivePref = 1;
		}
		if(UpgradeKeeper.uSpin != 0) {
			spinPref = 1;
		}
 	}

	public void tick() {
		
	}

	public void render(Graphics g) {
		
		g.setColor(Color.BLUE.darker());
		g.fillRect(402, 240, 60, 137);
		g.setColor(Color.BLACK);
		g.drawRect(402, 240, 60, 137);
		g.setColor(Color.BLUE.darker());
		g.fillRoundRect(390, 200, 85, 85, 85, 85);
		g.setColor(Color.BLACK);
		g.drawRoundRect(390, 200, 85, 85, 85, 85);
	
	//	g.drawImage(dave, 327, 74, null);
		g.drawImage(speechBubble, 560, 80, null);
		
		g.setColor(Color.ORANGE.darker());
		g.fillRoundRect(620, 100, 100, 100, 100, 100);
		g.setColor(Color.RED.darker());
		g.fillRoundRect(626, 106, 88, 88, 88, 88);
		g.setColor(Color.ORANGE);
		g.fillRoundRect(631, 111, 78, 78, 78, 78);
		g.setColor(Color.YELLOW);
		g.fillRoundRect(635, 115, 70, 70, 70, 70);
		
		if(chedPref == 1) {
			g.setColor(Color.ORANGE.darker());          // CHEDDAR
			g.fillRoundRect(631, 111, 78, 78, 78, 78);
			g.setColor(Color.ORANGE);
			g.fillRoundRect(635, 115, 70, 70, 70, 70);
		}

		g.setColor(Color.BLACK);
		g.drawRoundRect(620, 100, 100, 100, 100, 100);
		g.drawRoundRect(626, 106, 88, 88, 88, 88);
		g.drawRoundRect(631, 111, 78, 78, 78, 78);
		
		g.setColor(Color.RED.darker());
		g.fillRoundRect(640, 137, 10, 10, 10, 10);  // PEPPERONIS
		g.fillRoundRect(648, 163, 10, 10, 10, 10);
		g.fillRoundRect(663, 150, 10, 10, 10, 10);
		g.fillRoundRect(668, 121, 10, 10, 10, 10);
		g.fillRoundRect(683, 144, 10, 10, 10, 10);
		g.fillRoundRect(685, 161, 10, 10, 10, 10);
		g.setColor(Color.BLACK);
		g.drawRoundRect(640, 137, 10, 10, 10, 10);
		g.drawRoundRect(648, 163, 10, 10, 10, 10);
		g.drawRoundRect(663, 150, 10, 10, 10, 10);
		g.drawRoundRect(668, 121, 10, 10, 10, 10);
		g.drawRoundRect(683, 144, 10, 10, 10, 10);
		g.drawRoundRect(685, 161, 10, 10, 10, 10);
		
		if(sausPref == 1) {
			g.setColor(Color.ORANGE.darker().darker().darker());
			g.fillRoundRect(695, 150, 4, 4, 4, 4);	// SAUSAGE
			g.fillRoundRect(659, 125, 4, 4, 4, 4);
			g.fillRoundRect(673, 172, 4, 4, 4, 4);
			g.fillRoundRect(655, 154, 4, 4, 4, 4);
			g.fillRoundRect(638, 145, 4, 4, 4, 4);
			g.fillRoundRect(680, 135, 4, 4, 4, 4);
			g.setColor(Color.BLACK);
			g.drawRoundRect(695, 150, 4, 4, 4, 4);
			g.drawRoundRect(659, 125, 4, 4, 4, 4);
			g.drawRoundRect(673, 172, 4, 4, 4, 4);
			g.drawRoundRect(655, 154, 4, 4, 4, 4);
			g.drawRoundRect(638, 145, 4, 4, 4, 4);
			g.drawRoundRect(680, 135, 4, 4, 4, 4);
		}
		
		if(mushPref == 1) {
			g.setColor(Color.WHITE);
			g.fillRoundRect(688, 128, 8, 5, 8, 5);  // MUSHROOMS
			g.fillRoundRect(652, 133, 8, 5, 8, 5);
			g.fillRoundRect(675, 157, 8, 5, 8, 5);
			g.fillRoundRect(639, 157, 8, 5, 8, 5);
			g.fillRoundRect(659, 175, 8, 5, 8, 5);
			g.setColor(Color.BLACK);
			g.drawRoundRect(688, 128, 8, 5, 8, 5);
			g.drawRoundRect(652, 133, 8, 5, 8, 5);
			g.drawRoundRect(675, 157, 8, 5, 8, 5);
			g.drawRoundRect(639, 157, 8, 5, 8, 5);
			g.drawRoundRect(659, 175, 8, 5, 8, 5);
		}
		
		if(onionPref == 1) {
			g.setColor(Color.WHITE.darker());
			g.drawRoundRect(651, 144, 6, 6, 6, 6);  // ONIONS
			g.drawRoundRect(673, 179, 6, 6, 6, 6);
			g.drawRoundRect(691, 139, 6, 6, 6, 6);
			g.drawRoundRect(647, 124, 6, 6, 6, 6);
			g.drawRoundRect(641, 164, 6, 6, 6, 6);
			g.setColor(Color.MAGENTA.darker());
			g.drawRoundRect(650, 143, 6, 6, 6, 6);
			g.drawRoundRect(672, 178, 6, 6, 6, 6);
			g.drawRoundRect(690, 138, 6, 6, 6, 6);
			g.drawRoundRect(646, 123, 6, 6, 6, 6);
			g.drawRoundRect(640, 163, 6, 6, 6, 6);
		}
		
		if(olivePref == 1) {
			g.setColor(Color.BLACK);
			g.drawRoundRect(662, 119, 3, 3, 3, 3);  // OLIVES
			g.drawRoundRect(642, 132, 3, 3, 3, 3);
			g.drawRoundRect(650, 150, 3, 3, 3, 3);
			g.drawRoundRect(670, 165, 3, 3, 3, 3);
			g.drawRoundRect(697, 159, 3, 3, 3, 3);
			g.drawRoundRect(673, 140, 3, 3, 3, 3);
			g.drawRoundRect(701, 140, 3, 3, 3, 3);
		}
		
		if(spinPref == 1) {
			g.setColor(Color.GREEN.darker().darker());
			g.fillRoundRect(685, 121, 8, 5, 8, 5);  // SPINACH
			g.fillRoundRect(682, 173, 8, 5, 8, 5);
			g.fillRoundRect(657, 164, 8, 5, 8, 5);
			g.fillRoundRect(635, 153, 8, 5, 8, 5);
			g.fillRoundRect(650, 132, 8, 5, 8, 5);
			g.fillRoundRect(697, 163, 8, 5, 8, 5);
			g.setColor(Color.BLACK);
			g.drawRoundRect(685, 121, 8, 5, 8, 5);
			g.drawRoundRect(682, 173, 8, 5, 8, 5);
			g.drawRoundRect(657, 164, 8, 5, 8, 5);
			g.drawRoundRect(635, 153, 8, 5, 8, 5);
			g.drawRoundRect(650, 132, 8, 5, 8, 5);
			g.drawRoundRect(697, 163, 8, 5, 8, 5);
		}
		g.setColor(Color.BLACK);
		g.drawLine(670, 100, 670, 200);
		g.drawLine(620, 150, 720, 150);
		g.drawLine(630, 180, 710, 120);
		g.drawLine(630, 120, 710, 180);
	}

	public Rectangle getBounds() {
		
		return null;
	}
	
	public static int scoreCheck() {
		int score = 100;
		
		if(GameDisplay.mozz != mozzPref) {
			score = score - 10;
		}
		if(GameDisplay.ched != chedPref) {
			score = score - 10;
		}
		if(GameDisplay.pepp != peppPref) {
			score = score - 10;
		}
		if(GameDisplay.saus != sausPref) {
			score = score - 10;
		}
		if(GameDisplay.mush != mushPref) {
			score = score - 10;
		}
		if(GameDisplay.onion != onionPref) {
			score = score - 10;
		}
		if(GameDisplay.olives != olivePref) {
			score = score - 10;
		}
		if(GameDisplay.spin != spinPref) {
			score = score - 10;
		}
		if(GameDisplay.isCooked != isCooked) {
			score = score - 20;
		}
		if(GameDisplay.isCut != isCut) {
			score = score - 10;
		}
		return score;
	}
}
