package pp.characters;
import java.util.Random;

import pp.AudioPlayer;
import pp.Game;
import pp.main.HUD;
import pp.main.Handler;
import pp.main.UpgradeKeeper;

public class Spawn {

	public static int timeKeep = 0;
	public static int daveSpawn = 0, billSpawn = 0, clintSpawn = 0,
					  annaSpawn = 0, paulaSpawn = 0, jacksonSpawn = 0,
					  sherylSpawn = 0, charlieSpawn = 0, maxwellSpawn = 0,
					  brucieSpawn = 0;
	
	private Random r = new Random();
	private Handler handler;
	@SuppressWarnings("unused")
	private Game game;
	@SuppressWarnings("unused")
	private HUD hud;
	
	public Spawn(Game game, Handler handler, HUD hud) {
		this.handler = handler;
		this.game = game;
		this.hud = hud;
	}
	
	public void tick() {
		timeKeep++;
		
		if(timeKeep == 100) {
			int characterNumber = r.nextInt(10 + 1 - 1) + 1;
			
			if(characterNumber == 1) {
				daveSpawn = 1;
				new Dave(0, 0, ID.Customer, handler);
			}
			else if(characterNumber == 2) {
				billSpawn = 1;
				new Bill(0, 0, ID.Customer, handler);
			}
			else if(characterNumber == 3) {
				clintSpawn = 1;
				new Clint(0, 0, ID.Customer, handler);
			}
			else if(characterNumber == 4) {
				annaSpawn = 1;
				new Anna(0, 0, ID.Customer, handler);
			}
			else if(characterNumber == 5) {
				paulaSpawn = 1;
				new Paula(0, 0, ID.Customer, handler);
			}
			else if(characterNumber == 6) {
				jacksonSpawn = 1;
				new Jackson(0, 0, ID.Customer, handler);
			}
			else if(characterNumber == 7) {
				sherylSpawn = 1;
				new Sheryl(0, 0, ID.Customer, handler);
			}
			else if(characterNumber == 8) {
				charlieSpawn = 1;
				new Charlie(0, 0, ID.Customer, handler);
			}
			else if(characterNumber == 9) {
				maxwellSpawn = 1;
				new Maxwell(0, 0, ID.Customer, handler);
			}
			else if(characterNumber == 10) {
				brucieSpawn = 1;
				new Brucie(0, 0, ID.Customer, handler);
			}
			if(!Game.muted && UpgradeKeeper.doorbellBought == 1) {
				AudioPlayer.getSound("bell").play(1, 0.15f);
			}
		}
	}
}
