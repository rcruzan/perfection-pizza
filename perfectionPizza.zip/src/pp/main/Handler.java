package pp.main;
import java.awt.Graphics;
import java.util.LinkedList;

import pp.Game;
import pp.GameObject;
import pp.characters.ID;


public class Handler {
	LinkedList<GameObject> object = new LinkedList<GameObject>();
	
	public void tick() {
		for(int i = 0; i < object.size(); i++) {
			GameObject tempObject = object.get(i);
			tempObject.tick();
		}
	}
	
	public void render(Graphics g) {
		for(int i = 0; i < object.size(); i++) {
			GameObject tempObject = object.get(i);
			tempObject.render(g);
		}
	}
	
	public void clearCustomers() {
		for(int i = 0; i < object.size(); i++) {
			GameObject tempObject = object.get(i);
			if(Game.gameState == Game.STATE.Game) {
			if(tempObject.getID() == ID.Customer) {
				removeObject(tempObject);
				i--;
				}
			}
			else {
				removeObject(tempObject);
				i--;
			}
		}
	}	
	
	public void clearParticles() {
		for(int i = 0; i < object.size(); i++) {
			GameObject tempObject = object.get(i);
			if(Game.gameState == Game.STATE.Game) {
			if(tempObject.getID() == ID.MenuParticle) {
				removeObject(tempObject);
				i--;
				}
			}
			else {
				removeObject(tempObject);
				i--;
			}
		}
	}	
	
	public void addObject(GameObject object) {
		this.object.add(object);
	}
	
	public void removeObject(GameObject object) {
		this.object.remove(object);
	}
}
