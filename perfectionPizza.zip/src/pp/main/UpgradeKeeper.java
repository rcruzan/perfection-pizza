package pp.main;

public class UpgradeKeeper {

	public static int upgradePage = 0;
	/* 0 = Category Selection,
	   1 = Ingredient Page 1, 2 = Ingredient Page 2, 3 = Ingredient Page 3
	   4 = Decoration Page 1, 5 = Decoration Page 2
	   6 = Gameplay Upgrades */
	
	/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
	   *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
	   *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
	
	// INGREDIENT LEVELS:
	public static int uSauce = 1, uMozz = 1, uChed = 0, uPepp = 1, uSaus = 0,
			          uMush = 0, uOnion = 0, uOlive = 0, uSpin = 0;
	// 0 = NOT BOUGHT, 1 = BOUGHT, 2 = UPGRADED, 3 = UPGRADED+ (for default '1' ingredients)
	// Sauce, Mozzarella and Pepperoni should all be set to '1' by default.				  
	
	// PRICES:
	public static int pSauce = 50, pMozz = 150, pChed = 200, pPepp = 250, pSaus = 300, 
				      pMush = 300, pOnion = 450, pOlive = 450, pSpin = 450;
	// These are the starting prices -- they will increase for the second upgrade.
	
	// MULTIPLIERS & OTHERS:
	public static int saucePlus = 2, mozzPlus = 2, chedPlus = 0, peppPlus = 3, sausPlus = 0,
					  mushPlus = 0, onionPlus = 0, olivePlus = 0, spinPlus = 0;
	
	/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
	   *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
	   *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
	
	// DECORATION LEVELS:
	public static int lampsBought = 0, poster1Bought = 0, poster2Bought = 0,
					  plantsBought = 0, wallpaperBought = 0, doorbellBought = 0;
	// 0 = NOT BOUGHT, 1 = BOUGHT
	
	// PRICES:
	public static int pDoorbell = 225, pPoster1 = 350, pPoster2 = 350,
					  pPlants = 450, pLamps = 400, pWallpaper = 500;
	
	/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
	   *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
	   *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
	
	// GAMEPLAY LEVELS:
	public static int gDayTime = 0, gCookTime = 0, gMoneyMul = 0;
	// 0 = NOT BOUGHT, 1 = BOUGHT, 2 = UPGRADED
	     
	// PRICES:
	public static int pDaytime = 650, pCookTime = 450, pMoneyMul = 1000;
	
	// MULTIPLIERS & OTHERS:
	public static int cooktimeMinus = 0, moneyMultiplier = 1;
	public static float daytimePlus = 0.02175f;
	
	// 0.02175, 0.0163125, 0.010875
}
