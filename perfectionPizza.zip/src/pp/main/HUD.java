package pp.main;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import pp.Game;

public class HUD {
	public static float TIME = 100;
	public static int money = 0;
	public static int day = 1;
	//public static int day = 30;
	
	public void tick() {
		TIME = Game.clamp(TIME, 0, 100);
		
	//	TIME = TIME - 0.001f;					  // SLOW TIME for DISPLAY DEBUG
		TIME = TIME - UpgradeKeeper.daytimePlus;  // NORMAL TIME
	//	TIME = TIME - 3f;						  // FAST TIME for MENU DEBUG

	}
	
	public void render(Graphics g) {
		g.setColor(Color.GRAY);
		g.fillRect(330, 15, 200, 32);
		
		g.setColor(Color.YELLOW);
		g.fillRect(330, 15,(int) TIME * 2, 32);
		
		g.setColor(Color.BLACK);
		g.drawRect(330, 15, 200, 32);
		g.setColor(Color.WHITE);
		g.drawRect(329, 14, 200, 32);
		
		// *-*-*-*-*-*-*-*-*-*-*-*-*-*
		
		Font f = new Font("Arial", Font.BOLD, 16);
		g.setFont(f);
		g.setColor(Color.BLACK);
		g.drawString("Money: $" + money, 548, 38);
		
		g.setColor(Color.WHITE);
		g.drawString("Money: $" + money, 547, 37);
		
		
		if(day <= 9) {
			g.setColor(Color.BLACK);
			g.drawString("Day: " + day, 268, 38);
			g.setColor(Color.WHITE);
			g.drawString("Day: " + day, 267, 37);
		}
		else {
			g.setColor(Color.BLACK);
			g.drawString("Day: " + day, 262, 38);
			g.setColor(Color.WHITE);
			g.drawString("Day: " + day, 261, 37);
		}
	}
	
	@SuppressWarnings({ "unused", "static-access" })
	private void money(int money) {
		this.money = money;
	}
	
	public static int getMoney() {
		return money;
	}
	
	public static int getDay() {
		return day;
	}
	
	public void setDay(int d) {
		day = d;
	}
}
